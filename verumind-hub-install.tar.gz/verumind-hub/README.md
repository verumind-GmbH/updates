# verumind Hub — Installationspaket

Dieses Verzeichnis enthält alles, was für Installation und Betrieb von
verumind Hub auf Ihrem Server nötig ist. **Kein Quellcode** — die Programm-Images
werden fertig aus der verumind-Registry geladen.

## Womit anfangen

Lesen Sie **`INSTALLATION.md`** und arbeiten Sie es von oben nach unten ab.
Beginnen Sie mit der Checkliste in Abschnitt 1 — sie nennt alles, was Sie
*beschaffen* müssen, bevor Sie loslegen.

```bash
less INSTALLATION.md
```

## Die Dateien

| Datei | Wozu |
|---|---|
| `INSTALLATION.md` | **Hier anfangen.** Führt einmal linear durch die Installation. |
| `BETRIEB.md` | Nachschlagewerk für später: Updates, Sicherung, Fehlersuche, Support. |
| `README.md` | Diese Übersicht. |
| `firewall-ziele.txt` | Die benötigten Firewall-Freigaben — zum Weiterreichen an Ihre Netzwerkabteilung. |
| `pruefe-server.sh` | Prüft, ob der Server für die Installation geeignet ist. **Ändert nichts.** Jederzeit gefahrlos aufrufbar. |
| `install.sh` | Das Installationsskript. |
| `admin-reset.sh` | Notausgang, falls niemand mehr ins Portal kommt (Passwort vergessen, 2FA-Gerät verloren). |
| `docker-compose.prod.yml` | Beschreibt die fünf Komponenten. Wird für alle Betriebsbefehle benötigt. Nicht von Hand ändern. |
| `Caddyfile` | Konfiguration des Reverse-Proxy (HTTPS). Nicht von Hand ändern. |
| `.env.prod.example` | **Reine Dokumentation** aller Konfigurationswerte. Muss nicht bearbeitet werden — der Installer erzeugt die echte `.env` selbst. Zum Nachschlagen. |
| `zertifikat-pruefen.sh` | Prüft ein selbst mitgebrachtes HTTPS-Zertifikat, bevor das Portal damit neu startet. **Ändert nichts.** |
| `PAKET-VERSION` | Aus welchem Stand dieses Paket gebaut wurde. Bei Supportanfragen hilfreich. |

## Der kurze Weg

Vorausgesetzt, die Checkliste aus `INSTALLATION.md` Abschnitt 1 ist erfüllt:

```bash
cd /opt/verumind-hub
chmod +x install.sh pruefe-server.sh

sh pruefe-server.sh hub.ihre-firma.de    # prüft — ändert nichts
sudo ./install.sh                         # installiert
```

Nach der Installation läuft das Portal, es sind aber noch **keine Fachmodule
sichtbar** — dafür wird ein Lizenzschlüssel benötigt, den verumind erst nach der
Installation ausstellen kann. Siehe `INSTALLATION.md`, Abschnitt 10.

## Kontakt

| Adresse | Wofür |
|---|---|
| **aktivierung@verumind.de** | Lizenz und Freischaltung |
| **support@verumind.de** | Support, Störungen, Registry-Token |

---

*verumind GmbH*
