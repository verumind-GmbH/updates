# verumind Hub — Installation

**Zielgruppe:** interne IT-Abteilungen und IT-Systemhäuser.
**Voraussetzung an Kenntnissen:** Linux, Docker, Kommandozeile.

Diese Anleitung führt **einmal linear** durch die Installation. Arbeiten Sie sie von
oben nach unten ab. Jeder Schritt endet mit einer Prüfung, an der Sie erkennen, ob
er geklappt hat.

Für den laufenden Betrieb — Updates, Sicherung, Fehlersuche — gibt es ein zweites
Dokument: **BETRIEB.md** (liegt daneben).

---

## Zeitbedarf — realistisch

| | |
|---|---|
| **Reine Arbeit am Server** | **30–45 Minuten** |
| **Planen Sie ein** | **2 Stunden** |
| **Bis das Produkt nutzbar ist** | **1–2 Werktage** |

Die 30–45 Minuten gelten nur, wenn alles aus Abschnitt 1 bereitliegt. Die zwei
Stunden decken das ab, was erfahrungsgemäß dazwischenkommt: ein DNS-Eintrag, der
erst gesetzt werden muss, eine Firewall-Freigabe, die eine andere Abteilung
erledigt, eine Rückfrage.

**Wichtig:** Nach der Installation läuft das Portal, aber es sind noch **keine
Fachmodule sichtbar**. Dafür wird ein Lizenzschlüssel benötigt, den verumind erst
ausstellen kann, wenn Ihre Installation existiert (Abschnitt 8). Die Ausstellung
dauert in der Regel **einen Werktag**. Rechnen Sie das in Ihre Terminplanung ein —
der Server ist nach zwei Stunden fertig, das Produkt ist es nicht.

---

## 1 · Bevor Sie anfangen — Checkliste

Beschaffen Sie **alle** folgenden Punkte, **bevor** Sie sich auf dem Server
anmelden. Fehlt einer, kommen Sie mittendrin nicht weiter.

### 1.1 Zugang zum Server

- [ ] **Öffentliche IPv4-Adresse** des Servers
- [ ] **Anmeldeweg:** SSH-Zugang als `root` oder ein Benutzer mit `sudo`
- [ ] **SSH-Schlüssel oder Passwort** — geklärt, wer ihn bereitstellt

> Wenn Sie den Server von einem Kunden oder Hoster übernehmen: Klären Sie den
> Zugang **schriftlich vorab**. Diese Anleitung setzt voraus, dass Sie sich
> anmelden können; sie kann Ihnen den Zugang nicht verschaffen.

### 1.2 Server-Ausstattung

| | Mindestens | Empfohlen |
|---|---|---|
| CPU | 2 Kerne (x86-64) | 4 Kerne |
| Arbeitsspeicher | 4 GB | 8 GB |
| Festplatte (SSD) | 40 GB frei | 80 GB frei |

**Betriebssystem — freigegeben sind:**

- Ubuntu 22.04 LTS, 24.04 LTS, 26.04 LTS
- Debian 12

Andere 64-bit-Linux-Distributionen funktionieren erfahrungsgemäß, sind aber **nicht
getestet**. Wenn Sie eine andere einsetzen möchten, stimmen Sie das vorher mit
verumind ab (support@verumind.de).

Zusätzlich: **Zeitsynchronisation (NTP) muss aktiv sein.** Ohne korrekte Uhrzeit
schlagen Zertifikatsausstellung und Anmeldungen fehl.

### 1.3 Domain und DNS

- [ ] **(Sub-)Domain** für das Portal festgelegt, z. B. `hub.ihre-firma.de`
- [ ] **A-Record** dieser Domain zeigt auf die öffentliche IP des Servers
- [ ] **Geklärt, wer den DNS-Eintrag setzen darf** — oft eine andere Abteilung
      oder ein externer Dienstleister

> Der DNS-Eintrag muss **vor** der Installation aktiv sein. Ohne ihn kann kein
> HTTPS-Zertifikat ausgestellt werden. Je nach TTL dauert es nach der Änderung
> einige Minuten bis Stunden, bis der Eintrag überall bekannt ist.

### 1.4 Registry-Token von verumind

- [ ] **Registry-Token** liegt vor

Das Token berechtigt Ihren Server, die Programm-Images zu laden. **Ohne Token ist
keine Installation möglich** — sie bricht ab.

| | |
|---|---|
| **Wer stellt es aus?** | verumind GmbH |
| **Wie bekommen Sie es?** | Es wird Ihnen im Rahmen der Beauftragung zugesandt. |
| **Wie sieht es aus?** | Eine lange Zeichenkette, beginnend mit `ghp_` oder `github_pat_` |
| **Sie haben keins?** | Fordern Sie es an: **support@verumind.de**, Betreff `Registry-Token — <Ihre Organisation>`. Fangen Sie nicht ohne an. |
| **Vertraulichkeit** | Behandeln Sie es wie ein Passwort. Nicht per unverschlüsselter Mail weiterleiten, nicht in eine Versionsverwaltung einchecken. |

Das Token ist an einen aktiven Wartungsvertrag gebunden. Läuft es ab, können keine
**neuen** Versionen mehr geladen werden — bereits laufende Container laufen
unverändert weiter.

### 1.5 Die fünf Angaben für den Installer

Legen Sie diese fünf Werte **schriftlich** fest, bevor Sie starten. Der Installer
fragt sie ab und **bestätigt sie nicht noch einmal** — er startet direkt durch.

| Angabe | Was einzugeben ist | Anforderungen |
|---|---|---|
| **Domain** | Die Portal-Adresse, z. B. `hub.ihre-firma.de` | Ohne `https://`, ohne Schrägstrich am Ende. **Muss exakt der Domain entsprechen, für die der DNS-A-Record gesetzt ist.** |
| **E-Mail für Zertifikat** | Kontaktadresse für Let's Encrypt | Gültige Adresse. Let's Encrypt schickt dorthin Warnungen, falls die Erneuerung ausfällt. Ein Funktionspostfach ist besser als eine persönliche Adresse. |
| **Admin-E-Mail** | Login des ersten Administrators | Gültige Adresse. Wird der Benutzername für die Anmeldung. |
| **Admin-Passwort** | Passwort dieses Administrators | **Mindestens 12 Zeichen, dazu mindestens ein Großbuchstabe, ein Kleinbuchstabe, eine Ziffer und ein Sonderzeichen.** Der Installer prüft das und fragt bei einer Fehleingabe erneut (bis zu fünf Mal); er nennt dabei, welche Bedingung fehlt. Beispiel für ein gültiges Passwort: `Hafen-Kran-2026!` — bitte nicht wörtlich übernehmen. Dieses Konto hat Vollzugriff auf ein aus dem Internet erreichbares System. |
| **Registry-Token** | siehe 1.4 | — |

Die **Version** fragt der Installer ebenfalls ab, schlägt aber die aktuelle selbst
vor. Dort genügt **Enter**.

> **Tippfehler in der Domain sind teuer.** Es gibt keine Bestätigungsabfrage. Eine
> falsche Domain bedeutet: kein Zertifikat, und die Installation muss wiederholt
> werden — dabei werden Admin-Passwort und alle Zugangsgeheimnisse **neu vergeben**.
> Prüfen Sie die Schreibweise, bevor Sie Enter drücken.

### 1.6 Firewall-Freigaben

Diese Tabelle können Sie unverändert an Ihre Netzwerkabteilung weitergeben. Sie
liegt zusätzlich als Datei `firewall-ziele.txt` im Installationspaket.

**Eingehend zum Server:**

| Port | Protokoll | Wofür |
|---|---|---|
| 80 | TCP | Ausstellung und Erneuerung des HTTPS-Zertifikats; leitet auf HTTPS weiter |
| 443 | TCP | Das Portal selbst |
| 443 | **UDP** | HTTP/3 (QUIC). **Optional.** Ohne diese Freigabe funktioniert das Portal vollständig, es fällt auf HTTP/2 über TCP zurück. |

**Ausgehend vom Server (jeweils HTTPS/443/TCP):**

| Hostname | Wofür |
|---|---|
| `ghcr.io` | Anmeldung an der Programm-Registry |
| `pkg-containers.githubusercontent.com` | **Laden der Programm-Images.** Wird oft übersehen. |
| `updates.verumind.de` | Installationspaket und Versionsprüfung |
| `acme-v02.api.letsencrypt.org` | Ausstellung des HTTPS-Zertifikats |

> **Häufigster Fehler bei restriktiven Firewalls:** Nur `ghcr.io` wird freigegeben,
> `pkg-containers.githubusercontent.com` nicht. Die Anmeldung an der Registry
> gelingt dann, das Laden der Images bricht ab. Das Fehlerbild ist schwer zu
> deuten — geben Sie beide Ziele frei.

**Kein externer Dienst meldet sich beim Server zurück** — das Portal fragt selbst
nach, wenn ein länger laufender Auftrag fertig sein könnte. Die Ports 80 und 443
oben sind damit die einzigen eingehenden Freigaben, und sie betreffen nur den
Zugriff Ihrer eigenen Mitarbeiter.

> **Eine Ausnahme, voreingestellt aus.** Telefon-Durchwahlen einzelner
> Ansprechpartner lassen sich bei Apollo.io abrufen; Apollo meldet die Nummern
> einige Minuten später von sich aus zurück und bietet keinen anderen Weg an.
> Die Funktion ist deshalb **standardmäßig ausgeschaltet** — solange sie das
> bleibt, gilt der Absatz oben unverändert. Wer sie einschaltet, braucht **keine
> zusätzliche Firewall-Regel** (der Rückruf kommt über dieselbe HTTPS-Freigabe
> auf Port 443), wohl aber eine Portal-Adresse, die **aus dem Internet**
> erreichbar ist. Details in der Hilfe unter Administration → Durchwahlen über
> Apollo.

---

## 2 · Docker installieren

Auf dem Server müssen vorhanden sein:

- **Docker Engine**, Version 24 oder neuer
- **Docker Compose v2** (das `docker compose`-Plugin)
- `openssl` und `curl` — auf den meisten Systemen bereits vorhanden

verumind installiert Docker **bewusst nicht automatisch**, um Ihren internen
Richtlinien nicht vorzugreifen.

**Installieren Sie Docker nach Ihren IT-Vorgaben.** Haben Sie keine eigenen,
folgen Sie der offiziellen Anleitung:

**https://docs.docker.com/engine/install/**

Dort wählen Sie Ihre Distribution und folgen dem Abschnitt *„Install using the
apt repository"*. Installieren Sie diese Pakete:

```
docker-ce  docker-ce-cli  containerd.io  docker-buildx-plugin  docker-compose-plugin
```

### Woran Sie erkennen, dass es geklappt hat

Alle drei Befehle müssen fehlerfrei durchlaufen:

```bash
docker --version
docker compose version
docker run --rm hello-world
```

Erwartete Ausgabe (Versionsnummern können abweichen):

```
Docker version 29.7.1, build e9452d6
Docker Compose version v5.3.1
...
Hello from Docker!
```

Meldet `docker compose version` einen Fehler, fehlt das Compose-**Plugin**. Das
ältere, separate `docker-compose` (mit Bindestrich) genügt **nicht**.

---

## 3 · Ports freigeben

Die Freigaben aus Abschnitt 1.6 müssen wirksam sein. Prüfen Sie zuerst, ob auf dem
Server überhaupt eine Firewall aktiv ist:

```bash
ufw status
```

**Fall A — Ausgabe `Status: inactive`:**

Es ist keine lokale Firewall aktiv. Auf dem Server ist **nichts zu tun**. Prüfen
Sie stattdessen die vorgelagerte Firewall bzw. Sicherheitsgruppe Ihres Hosters.

> Führen Sie hier **nicht** `ufw enable` aus, ohne vorher SSH freizugeben — Sie
> sperren sich sonst sofort selbst aus. Wenn Sie ufw aktivieren wollen, dann in
> genau dieser Reihenfolge:
>
> ```bash
> ufw allow 22/tcp     # ZUERST — sonst verlieren Sie den Zugang
> ufw allow 80/tcp
> ufw allow 443/tcp
> ufw allow 443/udp    # optional, für HTTP/3
> ufw enable
> ```
>
> Läuft Ihr SSH auf einem anderen Port als 22, passen Sie die erste Zeile an.

**Fall B — Ausgabe `Status: active`:**

Ergänzen Sie die Regeln:

```bash
ufw allow 80/tcp
ufw allow 443/tcp
ufw allow 443/udp    # optional, für HTTP/3
```

`ufw` meldet jede Regel **zweimal** (`Rules updated` und `Rules updated (v6)`) —
einmal für IPv4, einmal für IPv6. Das ist normal.

### Woran Sie erkennen, dass es geklappt hat

```bash
ufw status
```

Bei aktiver Firewall müssen 80 und 443 als `ALLOW` gelistet sein. Bei inaktiver
Firewall bleibt die Ausgabe `Status: inactive` — die Prüfung im nächsten Abschnitt
zeigt Ihnen dann, ob die Ports tatsächlich erreichbar sind.

---

## 4 · Installationspaket laden

```bash
curl -fsSL https://updates.verumind.de/verumind-hub-install.tar.gz | tar -xz -C /opt
cd /opt/verumind-hub
chmod +x install.sh pruefe-server.sh
```

Die Adresse ist fest und versionsneutral — sie liefert immer den aktuellen
Installer. Welche Programmversion installiert wird, ermittelt das Skript später
selbst.

**Optional: Paket auf Unversehrtheit prüfen.** Verlangen Ihre IT-Richtlinien das,
laden Sie zuerst herunter, prüfen und entpacken erst danach:

```bash
cd /tmp
curl -fsSLO https://updates.verumind.de/verumind-hub-install.tar.gz
curl -fsSLO https://updates.verumind.de/verumind-hub-install.tar.gz.sha256
sha256sum -c verumind-hub-install.tar.gz.sha256
tar -xzf verumind-hub-install.tar.gz -C /opt
cd /opt/verumind-hub && chmod +x install.sh pruefe-server.sh
```

Die Prüfung muss `verumind-hub-install.tar.gz: OK` melden. Weicht die Ausgabe ab,
brechen Sie ab und wenden sich an **support@verumind.de**.

**Ohne Internetzugang des Servers:** Lassen Sie sich das Paket von verumind
zusenden, übertragen Sie es per `scp`/SFTP und entpacken Sie es nach `/opt`.

### Woran Sie erkennen, dass es geklappt hat

```bash
ls -la /opt/verumind-hub
```

Es müssen **zwölf** Dateien vorhanden sein, alle mit Besitzer `root` — welche das
sind und wozu sie dienen, steht in `README.md` im selben Verzeichnis (Übersicht
auch in Abschnitt 11).

Die drei Skripte (`install.sh`, `pruefe-server.sh`, `admin-reset.sh`) müssen als
ausführbar gekennzeichnet sein, erkennbar am `x` in der Rechteangabe
(`-rwxr-xr-x`). Ist das nicht der Fall, wurde das Archiv unterwegs verändert —
bitte erneut herunterladen und die Prüfsumme vergleichen.

---

## 5 · Server prüfen

**Dieser Schritt ist der wichtigste vor der Installation.** Das mitgelieferte
Prüfskript stellt in etwa einer Minute fest, ob der Server geeignet ist — und
findet Probleme, die sonst erst mitten in der Installation auffallen.

Das Skript **ändert nichts**: Es installiert nicht, startet keine Dienste und legt
keine Dateien an. Es liest, fragt und meldet.

```bash
cd /opt/verumind-hub
sh pruefe-server.sh hub.ihre-firma.de
```

Sie werden nach dem Registry-Token gefragt (Eingabe bleibt unsichtbar).

**Weitere Aufrufmöglichkeiten:**

```bash
sh pruefe-server.sh                              # fragt nach Domain und Token
sh pruefe-server.sh hub.ihre-firma.de            # Domain als Argument
sh pruefe-server.sh hub.ihre-firma.de --ohne-token   # Token-Prüfung überspringen
```

### Erwartete Ausgabe

```
verumind Hub — Serverprüfung
Es wird nur geprüft. An diesem Server wird nichts verändert.

1. System
  ✓ Linux (x86_64)
  ✓ 64-bit-Architektur
  ✓ Betriebssystem: Ubuntu 26.04 LTS
  ✓ Als root ausgeführt

2. Docker
  ✓ Docker 29.7.1
  ✓ Docker Compose 5.3.1

3. Ausstattung
  ✓ 4 CPU-Kerne (mindestens 2)
  ✓ 7740 MB Arbeitsspeicher (mindestens 4 GB)
  ✓ 142 GB frei auf /opt (mindestens 40 GB)

4. Ports 80 und 443
  ✓ Port 80 ist frei
  ✓ Port 443 ist frei

5. Zeigt hub.ihre-firma.de auf diesen Server?
  ✓ hub.ihre-firma.de zeigt auf diesen Server (203.0.113.10)

6. Ausgehende Verbindungen (HTTPS)
  ✓ ghcr.io erreichbar (Antwort 301)
  ✓ pkg-containers.githubusercontent.com erreichbar (Antwort 400)
  ✓ updates.verumind.de erreichbar (Antwort 200)
  ✓ acme-v02.api.letsencrypt.org erreichbar (Antwort 200)

7. Zugang zur Programm-Registry
  ✓ Token gültig — Anmeldung an ghcr.io erfolgreich
  ! Die Anmeldung bleibt bestehen; install.sh braucht sie ohnehin.

────────────────────────────────────────────────────────────
Dieser Server ist für die Installation geeignet.
(1 Hinweis(e) oben — kein Hindernis, aber lesenswert.)

Nächster Schritt:  sudo ./install.sh
```

**Zu Punkt 6 — die Antwortcodes irritieren, sind aber richtig:** Geprüft wird
ausschließlich, **ob die Gegenstelle antwortet**. Jede Antwort belegt das. `301`
(Weiterleitung) und `400` (die Gegenstelle erwartet eine andere Anfrage) sind an
dieser Stelle genauso gut wie `200`. Ein Verbindungsproblem würde stattdessen
`nicht erreichbar` melden.

**Zu Punkt 7 — der Hinweis am Ende:** Der gezählte Hinweis bezieht sich auf die
bestehenbleibende Registry-Anmeldung. Das ist beabsichtigt, `install.sh` benötigt
sie ohnehin.

### Woran Sie erkennen, dass es geklappt hat

Die Schlusszeile lautet **„Dieser Server ist für die Installation geeignet."**
Der Rückgabewert ist `0`:

```bash
sh pruefe-server.sh hub.ihre-firma.de ; echo "Rückgabewert: $?"
```

**Fahren Sie erst fort, wenn diese Prüfung fehlerfrei ist.** Jeder rote Punkt
bedeutet ein Problem, das später ohnehin auftritt — dann aber mitten in der
Installation und schwerer zu deuten.

---

## 6 · Registry-Zugang prüfen

Dieser Schritt entfällt, wenn `pruefe-server.sh` das Token bereits erfolgreich
geprüft hat (Punkt 7 der Ausgabe). Führen Sie ihn nur aus, wenn Sie das Skript mit
`--ohne-token` aufgerufen haben.

```bash
docker login ghcr.io -u verumind-deploy
```

Bei der Abfrage `Password:` das Token einfügen — die Eingabe bleibt unsichtbar.

**Auf einer nicht-interaktiven Sitzung** (Skript, Automatisierung, SSH ohne
Terminal) funktioniert die Passwortabfrage nicht. Dann so:

```bash
printf '%s\n' 'IHR-TOKEN' | docker login ghcr.io -u verumind-deploy --password-stdin
```

> `verumind-deploy` ist das feste Bezugskonto von verumind — für alle
> Installationen identisch und kein Geheimnis. Vertraulich ist nur das Token.

### Woran Sie erkennen, dass es geklappt hat

Die Ausgabe lautet:

```
Login Succeeded
```

Meldet der Befehl einen Fehler, prüfen Sie das Token. Ohne erfolgreichen Login kann
der Installer die Programm-Images nicht laden.

---

## 7 · Installation ausführen

```bash
cd /opt/verumind-hub
sudo ./install.sh
```

Der Installer fragt **sechs** Werte ab, in dieser Reihenfolge:

1. **Domain des Portals** — z. B. `hub.ihre-firma.de`
2. **E-Mail für Let's-Encrypt-Zertifikat**
3. **Admin-E-Mail (erster Login)**
4. **Admin-Passwort** — Eingabe bleibt unsichtbar
5. **Registry-Token** — Eingabe bleibt unsichtbar
6. **Version** — der Installer schlägt die aktuelle vor: **Enter** genügt

Alle sechs Werte haben Sie in Abschnitt 1.5 festgelegt.

> **Es gibt keine Bestätigungsabfrage.** Nach der Eingabe der Version startet der
> Installer sofort durch. Prüfen Sie besonders die Domain, bevor Sie Enter drücken.

### Was Sie auf dem Bildschirm sehen werden

Nach den Abfragen lädt der Installer fünf Programm-Images herunter. Dabei
erscheinen **mehrere hundert Zeilen** Fortschrittsmeldungen der Art:

```
 b3b2cae3c3fd Downloading 35.65MB
 597c6c618d36 Extracting 1B
 Image ghcr.io/verumind-gmbh/verumind-hub-backend:<version> Pulled
```

**Das ist normal.** Diese Ausgabe stammt von Docker, nicht vom Installer. Lassen
Sie sie durchlaufen — je nach Anbindung dauert das zwei bis zehn Minuten.

Danach werden die Komponenten gestartet. Der Installer wartet, bis das Backend
betriebsbereit ist.

### Woran Sie erkennen, dass es geklappt hat

Am Ende erscheint ein grün hervorgehobener Block:

```
✓ Installation abgeschlossen.
Portal:  https://hub.ihre-firma.de
Login:   admin@ihre-firma.de  (Passwort wie eingegeben)
! Hinweis: Das HTTPS-Zertifikat kann nach dem ersten Aufruf ein paar Sekunden brauchen.
! Bitte nach dem ersten Login das Admin-Passwort ändern.
```

Zusätzlich prüfbar:

```bash
cd /opt/verumind-hub
docker compose -f docker-compose.prod.yml ps
```

Es müssen **fünf** Container laufen. `postgres`, `backend` und `frontend` zeigen
`(healthy)`:

```
NAME                      STATUS
verumind-hub-backend-1    Up 26 minutes (healthy)
verumind-hub-caddy-1      Up 26 minutes
verumind-hub-frontend-1   Up 26 minutes (healthy)
verumind-hub-postgres-1   Up 27 minutes (healthy)
verumind-hub-updater-1    Up 27 minutes
```

*(`caddy` und `updater` haben keine Gesundheitsprüfung — dass sie `Up` sind,
genügt.)*

**Was der Installer im Hintergrund erledigt hat:** Er hat die aktuelle Version
ermittelt, alle übrigen Zugangsgeheimnisse selbst erzeugt (Datenbank-Passwort,
Verschlüsselungs- und Signatur-Schlüssel) und in die Datei `.env` geschrieben — nur
für den Eigentümer lesbar. Sie müssen davon nichts manuell setzen; **sichern
müssen Sie diese Datei aber unbedingt** (siehe BETRIEB.md, Abschnitt „Datensicherung").

---

## 8 · HTTPS prüfen

Das Zertifikat wird beim ersten Aufruf automatisch geholt. In der Praxis ist es
nach wenigen Sekunden da.

**Prüfen Sie es von der Kommandozeile** — dafür brauchen Sie keinen Browser:

```bash
curl -sI https://hub.ihre-firma.de/ | head -1
```

### Woran Sie erkennen, dass es geklappt hat

Der Befehl liefert eine HTTP-Antwort **ohne Zertifikatsfehler**:

```
HTTP/2 307
```

`307` ist korrekt: Die Startseite leitet auf `/login` weiter.

Meldet `curl` stattdessen `SSL certificate problem` oder `Could not resolve host`,
warten Sie 30 Sekunden und wiederholen Sie den Aufruf.

**Zertifikat im Detail ansehen:**

```bash
echo | openssl s_client -connect hub.ihre-firma.de:443 \
  -servername hub.ihre-firma.de 2>/dev/null \
  | openssl x509 -noout -issuer -subject -dates
```

Erwartet:

```
issuer=C=US, O=Let's Encrypt, CN=YE1
subject=CN=hub.ihre-firma.de
notBefore=Aug  3 07:00:39 2026 GMT
notAfter=Nov  1 07:00:38 2026 GMT
```

Entscheidend: Aussteller ist **Let's Encrypt** (kein selbstsigniertes Zertifikat)
und `subject` nennt **Ihre** Domain.

**Gesamtzustand prüfen:**

```bash
curl -s https://hub.ihre-firma.de/backend/health
```

Erwartet:

```json
{"status":"ok","db":"connected","version":"<version>",
 "instanceId":"296f8d8f-36f8-4da0-907e-5dcf668e92c1",
 "timestamp":"2026-08-03T07:59:29.851Z"}
```

Entscheidend sind `"status":"ok"` und `"db":"connected"`. Versionsnummer,
Instanz-Kennung und Zeitstempel sind bei Ihnen andere — die Version ist die
gerade installierte.

`"status":"ok"` und `"db":"connected"` bedeuten: Portal und Datenbank arbeiten.

> **Notieren Sie sich die `instanceId`** — das ist Ihre Instanz-Kennung. Sie
> brauchen sie im nächsten Schritt für die Lizenz.

---

## 9 · Anmelden und Passwort ändern

Öffnen Sie im Browser:

```
https://hub.ihre-firma.de
```

Es muss ein gültiges HTTPS-Schloss erscheinen. Melden Sie sich mit der
**Admin-E-Mail** und dem bei der Installation vergebenen **Passwort** an.

**Ändern Sie anschließend das Admin-Passwort:** *Einstellungen → Passwort ändern*.

> **Solange keine Lizenz hinterlegt ist, sind keine Fachmodule sichtbar.** Die
> Administration — Einstellungen, Benutzerverwaltung — ist bereits vollständig
> nutzbar. Das ist der erwartete Zustand, kein Fehler.

---

## 10 · Lizenz anfordern und einspielen

Der Lizenzschlüssel wird **fest an Ihre Installation gebunden**. Er funktioniert
nur dort und lässt sich nicht übertragen. Deshalb kann er erst ausgestellt werden,
wenn die Installation existiert.

### 10.1 Instanz-Kennung ermitteln

**Auf der Kommandozeile — der schnellste Weg:**

```bash
curl -s https://hub.ihre-firma.de/backend/health
```

Der Wert hinter `"instanceId"` ist Ihre Instanz-Kennung.

**Alternativ im Portal:** *Einstellungen → Installation → Version & Instanz*, Feld „Instanz-Kennung"

Beispiel: `296f8d8f-36f8-4da0-907e-5dcf668e92c1`

### 10.2 Lizenz anfordern

Senden Sie eine E-Mail an **aktivierung@verumind.de**. Hier eine vollständig
ausgefüllte Vorlage — ersetzen Sie die Beispielwerte durch Ihre eigenen:

```
An:      aktivierung@verumind.de
Betreff: Lizenz-Anforderung – Muster GmbH – hub.muster-gmbh.de

Sehr geehrtes verumind-Team,

wir haben verumind Hub installiert und bitten um Ausstellung des
Lizenzschlüssels.

Organisation:     Muster GmbH
Portal-Adresse:   https://hub.muster-gmbh.de
Instanz-Kennung:  296f8d8f-36f8-4da0-907e-5dcf668e92c1
Ansprechpartner:  Erika Mustermann, IT-Leitung
                  e.mustermann@muster-gmbh.de, +49 30 1234567

Mit freundlichen Grüßen
Erika Mustermann
```

**Zu den Feldern:**

| Feld | Was hineingehört |
|---|---|
| **Betreff** | `Lizenz-Anforderung – <Organisation> – <Portal-Domain>` |
| **Organisation** | Vollständiger Firmenname des Lizenznehmers — der Name, der auf dem Vertrag steht |
| **Portal-Adresse** | Vollständige URL inklusive `https://` |
| **Instanz-Kennung** | Aus 10.1, vollständig kopiert |
| **Ansprechpartner** | Name, Funktion, E-Mail und Telefonnummer für Rückfragen |

Sie erhalten den Lizenzschlüssel in der Regel **innerhalb eines Werktags**.

### 10.3 Lizenz einspielen

*Einstellungen → Lizenz →* Schlüssel einfügen *→ „Lizenz übernehmen"*

### Woran Sie erkennen, dass es geklappt hat

Die Karte zeigt **„Lizenz aktiv"** mit den freigeschalteten Modulen. Unter *Module*
erscheinen diese als „Aktiv" und werden in der Navigation sichtbar. Ein erneutes
Anmelden ist nicht nötig.

---

## 11 · Die Dateien im Installationsverzeichnis

Nach der Installation liegen in `/opt/verumind-hub`:

| Datei | Wozu |
|---|---|
| `INSTALLATION.md` | Dieses Dokument. |
| `BETRIEB.md` | Nachschlagewerk für den laufenden Betrieb: Updates, Sicherung, Fehlersuche. |
| `README.md` | Kurzübersicht über diese Dateien. |
| `install.sh` | Das Installationsskript (Abschnitt 7). Wird nach der Installation nicht mehr benötigt. |
| `pruefe-server.sh` | Prüft, ob der Server geeignet ist (Abschnitt 5). Ändert nichts — auch später jederzeit gefahrlos aufrufbar. |
| `admin-reset.sh` | Setzt das Passwort des Administrator-Kontos zurück. **Nur nötig, wenn Sie sich ausgesperrt haben.** Siehe BETRIEB.md. |
| `docker-compose.prod.yml` | Beschreibt die fünf Komponenten. Wird für alle Betriebsbefehle benötigt. Nicht von Hand ändern. |
| `Caddyfile` | Konfiguration des Reverse-Proxy (HTTPS). Nicht von Hand ändern. |
| `.env.prod.example` | **Reine Dokumentation** aller Konfigurationswerte, mit Erklärungen. Wird nicht gelesen und muss nicht bearbeitet werden — der Installer erzeugt die echte `.env` selbst. Zum Nachschlagen, was ein Wert bedeutet. |
| `zertifikat-pruefen.sh` | Prüft ein selbst mitgebrachtes HTTPS-Zertifikat (`certs/hub.crt`, `certs/hub.key`), bevor das Portal damit neu startet. Ändert nichts. |
| `firewall-ziele.txt` | Die benötigten Firewall-Freigaben zum Weiterreichen an die Netzwerkabteilung (Abschnitt 1.6). |
| `PAKET-VERSION` | Aus welchem Stand das Paket gebaut wurde. Bei Supportanfragen hilfreich. |

Zusätzlich entsteht bei der Installation:

| Datei | Wozu |
|---|---|
| `.env` | **Die wichtigste Datei der Installation.** Enthält alle Zugangsgeheimnisse und Verschlüsselungsschlüssel. Nur für den Eigentümer lesbar. **Muss gesichert werden** — ohne sie sind gespeicherte CRM-Zugangsdaten und Zwei-Faktor-Geheimnisse nach einer Wiederherstellung unbrauchbar. Siehe BETRIEB.md. |

---

## 12 · Fertig — und was jetzt noch fehlt

Nach Abschnitt 9 ist die **Installation** abgeschlossen: Das Portal läuft, HTTPS ist
gültig, das Administrator-Konto funktioniert. Der Server startet nach einem Neustart
selbstständig wieder — das ist geprüft.

**Das Produkt ist damit noch nicht einsatzbereit.** Es fehlt die Lizenz
(Abschnitt 10), und darauf warten Sie in der Regel einen Werktag.

**Empfohlene nächste Schritte:**

1. **Lizenz anfordern** (Abschnitt 10) — je früher, desto eher können Sie arbeiten.
2. **Datensicherung einrichten** — siehe BETRIEB.md. Sichern Sie **Datenbank und
   `.env` gemeinsam**; eine Sicherung ohne `.env` ist unvollständig.
3. **Entwicklerzugang erwägen** — siehe BETRIEB.md. Damit kann verumind im
   Störungsfall sofort helfen, statt erst auf eine Freischaltung zu warten.
4. **Benutzer und Abteilungen anlegen** — *Administration → Benutzerverwaltung → Benutzer* bzw. *→ Abteilungen*. Dafür wird keine Lizenz gebraucht.

---

## Kontakt

| Adresse | Wofür |
|---|---|
| **aktivierung@verumind.de** | Lizenz und Freischaltung |
| **support@verumind.de** | Support, Störungen, Registry-Token |

---

*verumind GmbH*
