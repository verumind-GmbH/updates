#!/usr/bin/env sh
# ─────────────────────────────────────────────────────────────────────────────
# Notausgang für ausgesperrte Administratoren.
#
# Wenn niemand mehr ins Portal kommt (Passwort vergessen, Zweitgerät für die
# Zwei-Faktor-Anmeldung verloren) und kein E-Mail-Versand eingerichtet ist, ist
# dies der Weg zurück. Im Verzeichnis der Installation ausführen (dort, wo die
# docker-compose-Datei liegt).
#
# Befehle:
#   ./admin-reset.sh list                              alle Konten anzeigen
#   ./admin-reset.sh password <email> [neues-passwort] Passwort neu setzen
#   ./admin-reset.sh 2fa-off  <email>                  2FA zurücksetzen
#   ./admin-reset.sh promote  <email>                  zum Administrator machen
#
# Jeder Eingriff wird im Audit-Log der Instanz protokolliert.
# ─────────────────────────────────────────────────────────────────────────────

# Kundeninstallationen laufen mit docker-compose.prod.yml, Entwicklungs- und
# Vorführinstanzen mit docker-compose.yml. Die passende Datei selbst finden,
# damit derselbe Befehl überall funktioniert.
if [ -f docker-compose.prod.yml ]; then
  COMPOSE_FILE=docker-compose.prod.yml
elif [ -f docker-compose.yml ]; then
  COMPOSE_FILE=docker-compose.yml
else
  echo "FEHLER: Keine docker-compose-Datei gefunden." >&2
  echo "Bitte im Verzeichnis der Installation ausführen (z.B. /opt/verumind-hub)." >&2
  exit 1
fi

exec docker compose -f "$COMPOSE_FILE" exec -T backend node dist/src/scripts/admin-reset.js "$@"
