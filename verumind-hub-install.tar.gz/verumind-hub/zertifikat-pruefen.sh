#!/bin/sh
# ==============================================================================
# Zertifikat prüfen — BEVOR das Portal damit neu startet.
#
# WARUM ES DIESES SKRIPT GIBT: Ein fehlerhaftes Zertifikat merkt man sonst erst,
# wenn Caddy nicht mehr startet — und dann ist das Portal für alle weg. Diese
# Prüfung ändert nichts, sie schaut nur nach und sagt, was fehlt.
#
# AUFRUF (im Projektordner, z. B. /opt/verumind-hub):
#     sh zertifikat-pruefen.sh
#
# Geprüft wird gegen die Erwartung des Portals: zwei Dateien, `certs/hub.crt`
# und `certs/hub.key`, beide im PEM-Format, der Schlüssel ohne Passwort.
# ==============================================================================
set -eu

CERT="certs/hub.crt"
KEY="certs/hub.key"
FEHLER=0

rot()   { printf '  \033[31m✗\033[0m %s\n' "$1"; FEHLER=$((FEHLER + 1)); }
gruen() { printf '  \033[32m✓\033[0m %s\n' "$1"; }
gelb()  { printf '  \033[33m!\033[0m %s\n' "$1"; }
titel() { printf '\n\033[1m%s\033[0m\n' "$1"; }

titel "1. Sind die beiden Dateien da?"

if [ ! -f "$CERT" ]; then
  rot "$CERT fehlt."
  printf '      Die Datei muss GENAU so heißen. Ein anderer Name wird ignoriert,\n'
  printf '      und das Portal holt sich weiter selbst ein Zertifikat über Port 80.\n'
else
  gruen "$CERT vorhanden ($(wc -c < "$CERT") Bytes)"
fi

if [ ! -f "$KEY" ]; then
  rot "$KEY fehlt."
else
  gruen "$KEY vorhanden ($(wc -c < "$KEY") Bytes)"
fi

[ "$FEHLER" -gt 0 ] && { printf '\nAbbruch: ohne beide Dateien ist keine weitere Prüfung möglich.\n\n'; exit 1; }

if ! command -v openssl >/dev/null 2>&1; then
  gelb "openssl ist nicht installiert — die inhaltliche Prüfung entfällt."
  printf '\nDie Dateien sind da. Ob sie zusammenpassen, kann hier nicht geprüft werden.\n\n'
  exit 0
fi

titel "2. Sind es PEM-Dateien?"

# PEM erkennt man am Block `-----BEGIN …-----`. Kommt von der
# Zertifizierungsstelle eine .pfx oder .der, muss sie erst umgewandelt werden
# (siehe Hinweis am Ende).
#
# GEPRÜFT WIRD DER INHALT, NICHT DIE ERSTE ZEILE.
#
# Anlass am 05.08.2026 bei HK: Das Zertifikat kam aus einem PKCS#12-Export
# (`openssl pkcs12 -out …`). Solche Dateien tragen vor jedem Block Kopfzeilen:
#
#     Bag Attributes
#         localKeyID: 8D F2 …
#         friendlyName: *.hkconsulting.de
#     -----BEGIN CERTIFICATE-----
#
# Die erste Zeile heißt also „Bag Attributes", und die frühere Prüfung meldete
# „kein PEM" — bei einer Datei, die vollkommen in Ordnung ist. Caddy kommt damit
# zurecht; es sucht die Blöcke und überliest den Rest. Ein Prüfskript, das
# strenger ist als das Programm, das es absichern soll, hält jemanden von einer
# funktionierenden Einrichtung ab. Das ist die teurere Fehlerrichtung: Ein
# falscher Alarm kostet Vertrauen in JEDE künftige Meldung.
if grep -q -- '-----BEGIN CERTIFICATE-----' "$CERT"; then
  gruen "Zertifikat ist PEM."
  # Kopfzeilen sind zulässig, aber erwähnenswert: Wer die Datei später von Hand
  # bearbeitet, soll wissen, dass dort mehr steht als die reinen Blöcke.
  head -1 "$CERT" | grep -q -- '-----BEGIN' ||
    gelb "Vor dem Zertifikat stehen Kopfzeilen (PKCS#12-Export). Das ist in Ordnung."
else
  rot "Zertifikat ist KEIN PEM (kein -----BEGIN CERTIFICATE----- gefunden)."
  printf '      Kommt es als .pfx, .p12 oder .der, muss es erst umgewandelt werden.\n'
fi

if grep -q -- '-----BEGIN' "$KEY"; then
  gruen "Schlüssel ist PEM."
else
  rot "Schlüssel ist KEIN PEM (kein -----BEGIN gefunden)."
fi

titel "3. Ist der Schlüssel ohne Passwort?"

# Caddy startet unbeaufsichtigt und kann kein Passwort erfragen. Ein
# verschlüsselter Schlüssel führt deshalb zu einem Start ohne HTTPS.
if grep -q "ENCRYPTED" "$KEY"; then
  rot "Der Schlüssel ist mit einem Passwort geschützt."
  printf '      Das Portal startet unbeaufsichtigt und kann kein Passwort erfragen.\n'
  printf '      Entfernen mit:  openssl rsa -in %s -out %s.neu && mv %s.neu %s\n' "$KEY" "$KEY" "$KEY" "$KEY"
else
  gruen "Schlüssel ohne Passwort."
fi

titel "4. Gehören Zertifikat und Schlüssel zusammen?"

# DER wichtigste Test. Zwei Dateien aus verschiedenen Vorgängen sehen einzeln
# völlig in Ordnung aus — zusammen ergeben sie kein funktionierendes HTTPS.
#
# Verglichen werden die ÖFFENTLICHEN SCHLÜSSEL, nicht die Modulus-Werte.
#
# GEGENPROBE AM 05.08.2026: Der erste Entwurf verglich den Modulus und fiel bei
# Abweichung in einen ECDSA-Zweig. Ein absichtlich vertauschter RSA-Schlüssel
# landete dort — und wurde als „kann man nicht prüfen" durchgewinkt. Ein Test,
# der seinen eigenen Anlassfall nicht findet, ist schlimmer als keiner: Er
# behauptet Sicherheit.
#
# `openssl pkey -pubout` beherrscht RSA und ECDSA gleichermaßen; damit
# entfällt die Fallunterscheidung, an der es gescheitert war.
C_PUB=$(openssl x509 -noout -pubkey -in "$CERT" 2>/dev/null || echo A)
K_PUB=$(openssl pkey -pubout -in "$KEY" 2>/dev/null || echo B)
if [ "$C_PUB" = "$K_PUB" ] && [ "$C_PUB" != "A" ]; then
  gruen "Sie gehören zusammen."
elif [ "$C_PUB" = "A" ] || [ "$K_PUB" = "B" ]; then
  rot "Eine der beiden Dateien ist nicht lesbar."
  printf '      Zertifikat und Schlüssel müssen im PEM-Format vorliegen.\n'
else
  rot "Zertifikat und Schlüssel gehören NICHT zusammen."
  printf '      Beide müssen aus demselben Vorgang stammen (gleiche Anforderung/CSR).\n'
  printf '      Häufigster Grund: Der Schlüssel stammt aus einer früheren Anforderung.\n'
fi

titel "5. Für welchen Namen gilt es, und wie lange?"

SUBJ=$(openssl x509 -noout -subject -in "$CERT" 2>/dev/null | sed 's/^subject=//')
NAMEN=$(openssl x509 -noout -ext subjectAltName -in "$CERT" 2>/dev/null | tail -n +2 | tr -d ' ' || true)
ENDE=$(openssl x509 -noout -enddate -in "$CERT" 2>/dev/null | sed 's/^notAfter=//')
printf '      Inhaber : %s\n' "${SUBJ:-unbekannt}"
printf '      Gilt für: %s\n' "${NAMEN:-—}"
printf '      Läuft ab: %s\n' "${ENDE:-unbekannt}"

if openssl x509 -checkend 0 -noout -in "$CERT" >/dev/null 2>&1; then
  if openssl x509 -checkend 2592000 -noout -in "$CERT" >/dev/null 2>&1; then
    gruen "Noch länger als 30 Tage gültig."
  else
    gelb "Läuft in weniger als 30 Tagen ab."
  fi
else
  rot "Das Zertifikat ist bereits abgelaufen."
fi

# Die Domain aus der .env gegenprüfen: Ein Zertifikat für den falschen Namen
# ist der Fehler, der am spätesten auffällt — der Browser zeigt dann eine
# Warnung, obwohl technisch alles läuft.
if [ -f .env ] && [ -n "${NAMEN:-}" ]; then
  DOMAIN=$(grep -E '^DOMAIN=' .env 2>/dev/null | cut -d= -f2- | tr -d '"' || true)
  if [ -n "$DOMAIN" ]; then
    # PLATZHALTER MÜSSEN MITGEZÄHLT WERDEN.
    #
    # GEFUNDEN AM 05.08.2026 bei HK: Das Zertifikat gilt für
    # `*.hkconsulting.de` und deckt `hub.hkconsulting.de` damit ab. Die frühere
    # Prüfung suchte stur nach der Zeichenkette, fand sie nicht und meldete
    # „gilt NICHT für die eingetragene Domain" — bei einem völlig korrekten
    # Zertifikat. Ein Wildcard-Zertifikat ist bei Firmen der Normalfall, nicht
    # die Ausnahme.
    #
    # Die Regel, die auch der Browser anwendet: `*.example.de` deckt GENAU EINE
    # weitere Stufe ab. Es passt auf `hub.example.de`, aber NICHT auf
    # `a.b.example.de` und NICHT auf `example.de` selbst.
    passt=0
    for name in $(printf '%s' "$NAMEN" | tr ',' '\n' | sed 's/^DNS://' | tr -d ' '); do
      [ -n "$name" ] || continue
      if [ "$name" = "$DOMAIN" ]; then
        passt=1
        break
      fi
      case "$name" in
        \*.*)
          rest=${name#\*.}
          case "$DOMAIN" in
            *".$rest")
              # Nur eine Stufe: Was vor `.$rest` steht, darf keinen Punkt haben.
              vorne=${DOMAIN%".$rest"}
              case "$vorne" in
                '' | *.*) ;;
                *) passt=1 ;;
              esac
              ;;
          esac
          ;;
      esac
      [ "$passt" = 1 ] && break
    done

    if [ "$passt" = 1 ]; then
      gruen "Passt zur eingetragenen Domain ($DOMAIN)."
    else
      rot "Gilt NICHT für die eingetragene Domain ($DOMAIN)."
      printf '      Der Browser würde eine Warnung zeigen, obwohl das Portal läuft.\n'
    fi
  fi
fi

titel "6. Ist die Kette vollständig?"

ANZAHL=$(grep -c -- '-----BEGIN CERTIFICATE-----' "$CERT" || true)
if [ "$ANZAHL" -ge 2 ]; then
  gruen "$ANZAHL Zertifikate in der Datei — Kette vorhanden."
else
  gelb "Nur ein Zertifikat in der Datei."
  printf '      Viele Zertifizierungsstellen liefern zusätzlich ein Zwischenzertifikat.\n'
  printf '      Fehlt es, meldet mancher Browser oder Java-Client die Seite als\n'
  printf '      nicht vertrauenswürdig, während Chrome sie klaglos anzeigt.\n'
  printf '      Anhängen mit:  cat zwischenzertifikat.crt >> %s\n' "$CERT"
fi

printf '\n'
if [ "$FEHLER" -gt 0 ]; then
  printf '\033[31m%s Punkt(e) müssen behoben werden.\033[0m Das Portal NICHT neu starten,\n' "$FEHLER"
  printf 'bevor sie erledigt sind — es liefe sonst ohne HTTPS.\n\n'
  exit 1
fi

printf '\033[32mAlles in Ordnung.\033[0m Übernehmen mit:\n\n'
printf '    docker compose -f docker-compose.prod.yml up -d caddy\n\n'
printf 'Danach im Protokoll nachsehen — dort steht, welcher Weg gewählt wurde:\n\n'
printf '    docker compose -f docker-compose.prod.yml logs caddy | grep verumind:\n\n'
