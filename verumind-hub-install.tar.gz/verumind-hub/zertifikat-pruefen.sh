#!/bin/sh
# ==============================================================================
# Zertifikat prüfen — BEVOR das Portal damit neu startet.
#
# WARUM ES DIESES SKRIPT GIBT: Ein fehlerhaftes Zertifikat merkt man sonst erst,
# wenn Caddy nicht mehr startet — und dann ist das Portal für alle weg. Diese
# Prüfung ändert nichts, sie schaut nur nach und sagt, was fehlt.
#
# AUFRUF (im Projektordner, z. B. /opt/verumind-hub):
#     sh zertifikat-pruefen.sh
#
# Geprüft wird gegen die Erwartung des Portals: zwei Dateien, `certs/hub.crt`
# und `certs/hub.key`, beide im PEM-Format, der Schlüssel ohne Passwort.
# ==============================================================================
set -eu

CERT="certs/hub.crt"
KEY="certs/hub.key"
FEHLER=0

rot()   { printf '  \033[31m✗\033[0m %s\n' "$1"; FEHLER=$((FEHLER + 1)); }
gruen() { printf '  \033[32m✓\033[0m %s\n' "$1"; }
gelb()  { printf '  \033[33m!\033[0m %s\n' "$1"; }
titel() { printf '\n\033[1m%s\033[0m\n' "$1"; }

titel "1. Sind die beiden Dateien da?"

if [ ! -f "$CERT" ]; then
  rot "$CERT fehlt."
  printf '      Die Datei muss GENAU so heißen. Ein anderer Name wird ignoriert,\n'
  printf '      und das Portal holt sich weiter selbst ein Zertifikat über Port 80.\n'
else
  gruen "$CERT vorhanden ($(wc -c < "$CERT") Bytes)"
fi

if [ ! -f "$KEY" ]; then
  rot "$KEY fehlt."
else
  gruen "$KEY vorhanden ($(wc -c < "$KEY") Bytes)"
fi

[ "$FEHLER" -gt 0 ] && { printf '\nAbbruch: ohne beide Dateien ist keine weitere Prüfung möglich.\n\n'; exit 1; }

if ! command -v openssl >/dev/null 2>&1; then
  gelb "openssl ist nicht installiert — die inhaltliche Prüfung entfällt."
  printf '\nDie Dateien sind da. Ob sie zusammenpassen, kann hier nicht geprüft werden.\n\n'
  exit 0
fi

titel "2. Sind es PEM-Dateien?"

# PEM beginnt mit -----BEGIN. Kommt von der Zertifizierungsstelle eine .pfx
# oder .der, muss sie erst umgewandelt werden (siehe Hinweis am Ende).
if head -1 "$CERT" | grep -q -- '-----BEGIN'; then
  gruen "Zertifikat ist PEM."
else
  rot "Zertifikat ist KEIN PEM (erste Zeile beginnt nicht mit -----BEGIN)."
fi

if head -1 "$KEY" | grep -q -- '-----BEGIN'; then
  gruen "Schlüssel ist PEM."
else
  rot "Schlüssel ist KEIN PEM."
fi

titel "3. Ist der Schlüssel ohne Passwort?"

# Caddy startet unbeaufsichtigt und kann kein Passwort erfragen. Ein
# verschlüsselter Schlüssel führt deshalb zu einem Start ohne HTTPS.
if grep -q "ENCRYPTED" "$KEY"; then
  rot "Der Schlüssel ist mit einem Passwort geschützt."
  printf '      Das Portal startet unbeaufsichtigt und kann kein Passwort erfragen.\n'
  printf '      Entfernen mit:  openssl rsa -in %s -out %s.neu && mv %s.neu %s\n' "$KEY" "$KEY" "$KEY" "$KEY"
else
  gruen "Schlüssel ohne Passwort."
fi

titel "4. Gehören Zertifikat und Schlüssel zusammen?"

# DER wichtigste Test. Zwei Dateien aus verschiedenen Vorgängen sehen einzeln
# völlig in Ordnung aus — zusammen ergeben sie kein funktionierendes HTTPS.
#
# Verglichen werden die ÖFFENTLICHEN SCHLÜSSEL, nicht die Modulus-Werte.
#
# GEGENPROBE AM 05.08.2026: Der erste Entwurf verglich den Modulus und fiel bei
# Abweichung in einen ECDSA-Zweig. Ein absichtlich vertauschter RSA-Schlüssel
# landete dort — und wurde als „kann man nicht prüfen" durchgewinkt. Ein Test,
# der seinen eigenen Anlassfall nicht findet, ist schlimmer als keiner: Er
# behauptet Sicherheit.
#
# `openssl pkey -pubout` beherrscht RSA und ECDSA gleichermaßen; damit
# entfällt die Fallunterscheidung, an der es gescheitert war.
C_PUB=$(openssl x509 -noout -pubkey -in "$CERT" 2>/dev/null || echo A)
K_PUB=$(openssl pkey -pubout -in "$KEY" 2>/dev/null || echo B)
if [ "$C_PUB" = "$K_PUB" ] && [ "$C_PUB" != "A" ]; then
  gruen "Sie gehören zusammen."
elif [ "$C_PUB" = "A" ] || [ "$K_PUB" = "B" ]; then
  rot "Eine der beiden Dateien ist nicht lesbar."
  printf '      Zertifikat und Schlüssel müssen im PEM-Format vorliegen.\n'
else
  rot "Zertifikat und Schlüssel gehören NICHT zusammen."
  printf '      Beide müssen aus demselben Vorgang stammen (gleiche Anforderung/CSR).\n'
  printf '      Häufigster Grund: Der Schlüssel stammt aus einer früheren Anforderung.\n'
fi

titel "5. Für welchen Namen gilt es, und wie lange?"

SUBJ=$(openssl x509 -noout -subject -in "$CERT" 2>/dev/null | sed 's/^subject=//')
NAMEN=$(openssl x509 -noout -ext subjectAltName -in "$CERT" 2>/dev/null | tail -n +2 | tr -d ' ' || true)
ENDE=$(openssl x509 -noout -enddate -in "$CERT" 2>/dev/null | sed 's/^notAfter=//')
printf '      Inhaber : %s\n' "${SUBJ:-unbekannt}"
printf '      Gilt für: %s\n' "${NAMEN:-—}"
printf '      Läuft ab: %s\n' "${ENDE:-unbekannt}"

if openssl x509 -checkend 0 -noout -in "$CERT" >/dev/null 2>&1; then
  if openssl x509 -checkend 2592000 -noout -in "$CERT" >/dev/null 2>&1; then
    gruen "Noch länger als 30 Tage gültig."
  else
    gelb "Läuft in weniger als 30 Tagen ab."
  fi
else
  rot "Das Zertifikat ist bereits abgelaufen."
fi

# Die Domain aus der .env gegenprüfen: Ein Zertifikat für den falschen Namen
# ist der Fehler, der am spätesten auffällt — der Browser zeigt dann eine
# Warnung, obwohl technisch alles läuft.
if [ -f .env ] && [ -n "${NAMEN:-}" ]; then
  DOMAIN=$(grep -E '^DOMAIN=' .env 2>/dev/null | cut -d= -f2- | tr -d '"' || true)
  if [ -n "$DOMAIN" ]; then
    if printf '%s' "$NAMEN" | grep -q "$DOMAIN"; then
      gruen "Passt zur eingetragenen Domain ($DOMAIN)."
    else
      rot "Gilt NICHT für die eingetragene Domain ($DOMAIN)."
      printf '      Der Browser würde eine Warnung zeigen, obwohl das Portal läuft.\n'
    fi
  fi
fi

titel "6. Ist die Kette vollständig?"

ANZAHL=$(grep -c -- '-----BEGIN CERTIFICATE-----' "$CERT" || true)
if [ "$ANZAHL" -ge 2 ]; then
  gruen "$ANZAHL Zertifikate in der Datei — Kette vorhanden."
else
  gelb "Nur ein Zertifikat in der Datei."
  printf '      Viele Zertifizierungsstellen liefern zusätzlich ein Zwischenzertifikat.\n'
  printf '      Fehlt es, meldet mancher Browser oder Java-Client die Seite als\n'
  printf '      nicht vertrauenswürdig, während Chrome sie klaglos anzeigt.\n'
  printf '      Anhängen mit:  cat zwischenzertifikat.crt >> %s\n' "$CERT"
fi

printf '\n'
if [ "$FEHLER" -gt 0 ]; then
  printf '\033[31m%s Punkt(e) müssen behoben werden.\033[0m Das Portal NICHT neu starten,\n' "$FEHLER"
  printf 'bevor sie erledigt sind — es liefe sonst ohne HTTPS.\n\n'
  exit 1
fi

printf '\033[32mAlles in Ordnung.\033[0m Übernehmen mit:\n\n'
printf '    docker compose -f docker-compose.prod.yml up -d caddy\n\n'
printf 'Danach im Protokoll nachsehen — dort steht, welcher Weg gewählt wurde:\n\n'
printf '    docker compose -f docker-compose.prod.yml logs caddy | grep verumind:\n\n'
