#!/usr/bin/env sh
# ─────────────────────────────────────────────────────────────────────────────
# verumind Hub — Server prüfen (L5)
#
# SHEBANG BEWUSST `sh`, NICHT `bash`: Die Anleitung sagt `sh pruefe-server.sh`,
# also muss dieses Skript ohne Bash-Eigenheiten auskommen. Vorher stand hier
# `bash` — das Skript lief zufällig trotzdem, weil es POSIX-sauber ist, aber die
# Zusage stand nirgends. Wer sich künftig auf den Shebang verlässt und eine
# Bash-Eigenheit einbaut, bricht damit den dokumentierten Aufruf. Mit `sh` fällt
# das sofort auf.
#
# Für install.sh gilt das Umgekehrte: Es BRAUCHT Bash (verborgene
# Passworteingabe) und weist einen Aufruf mit `sh` deshalb am Anfang ab.
#
# Prüft, ob dieser Server für eine Installation geeignet ist. ÄNDERT NICHTS:
# keine Installation, kein Dienst wird gestartet oder gestoppt, keine Datei
# angelegt. Das Skript liest, fragt und meldet — mehr nicht.
#
# WOFÜR ES DA IST: Nach der Installation kommt verumind nicht mehr an den Server.
# Was hier nicht auffällt, fällt später auf — und dann ohne Zugriff, per Telefon,
# beim Kunden. Dies ist die letzte Gelegenheit, ein Problem zu finden, solange
# noch jemand am Rechner sitzt.
#
# Aufruf:
#   sh pruefe-server.sh                        (fragt nach Domain und Token)
#   sh pruefe-server.sh hub.kunde.de           (Domain als Argument)
#   sh pruefe-server.sh hub.kunde.de --ohne-token
#
# Rückgabewert: 0 = geeignet, 1 = es fehlt etwas.
# ─────────────────────────────────────────────────────────────────────────────
set -u

# Farben über printf statt über $'…'. Die Kundenanleitung sagt „sh install.sh",
# und auf Ubuntu ist /bin/sh die Dash — dort ist $'…' keine Zeichenfolge, sondern
# ein Dollarzeichen gefolgt von einer eckigen Klammer. Gemessen am 02.08.2026:
# Die Prüfausgabe war mit „$[1m" durchsetzt und dadurch schwer lesbar.
ESC="$(printf '\033')"
ROT="${ESC}[0;31m"; GRUEN="${ESC}[0;32m"; GELB="${ESC}[0;33m"; FETT="${ESC}[1m"; AUS="${ESC}[0m"

# Anforderungen aus docs/kunden-installation.md, Abschnitt 2.
MIN_KERNE=2
MIN_RAM_MB=3600          # 4 GB laut Datenblatt; der Kernel meldet etwas weniger.
MIN_PLATTE_GB=40
REGISTRY_HOST="ghcr.io"

# Ausgehende Ziele. Jedes einzeln, weil ein teilweise geöffnetes Netz das
# schwerste Fehlerbild erzeugt: Die Anmeldung gelingt, das Laden bricht ab.
ZIELE="ghcr.io pkg-containers.githubusercontent.com updates.verumind.de acme-v02.api.letsencrypt.org"

FEHLER=0
WARNUNGEN=0
MAENGEL=""

ok()      { printf "  ${GRUEN}✓${AUS} %s\n" "$1"; }
mangel()  { printf "  ${ROT}✗${AUS} %s\n" "$1"; FEHLER=$((FEHLER + 1)); MAENGEL="${MAENGEL}
  • $1
    ↳ $2"; }
hinweis() { printf "  ${GELB}!${AUS} %s\n" "$1"; WARNUNGEN=$((WARNUNGEN + 1)); }
titel()   { printf "\n${FETT}%s${AUS}\n" "$1"; }

# ── Eingaben ─────────────────────────────────────────────────────────────────
DOMAIN="${1:-}"
case "$DOMAIN" in --*) DOMAIN="" ;; esac
OHNE_TOKEN=0
for a in "$@"; do [ "$a" = "--ohne-token" ] && OHNE_TOKEN=1; done

printf "\n${FETT}verumind Hub — Serverprüfung${AUS}\n"
printf "Es wird nur geprüft. An diesem Server wird nichts verändert.\n"

if [ -z "$DOMAIN" ]; then
  printf "\nUnter welcher Adresse soll das Portal erreichbar sein? (z. B. hub.kunde.de)\n> "
  read -r DOMAIN
fi
[ -z "$DOMAIN" ] && { printf "\n${ROT}Ohne Domain kann die Namensauflösung nicht geprüft werden.${AUS}\n\n"; exit 1; }

# ── 1. Betriebssystem und Werkzeuge ──────────────────────────────────────────
titel "1. System"

if [ "$(uname -s)" = "Linux" ]; then
  ok "Linux ($(uname -m))"
else
  mangel "Kein Linux ($(uname -s))" "Der Hub läuft ausschließlich auf 64-bit-Linux."
fi

case "$(uname -m)" in
  x86_64|amd64) ok "64-bit-Architektur" ;;
  aarch64|arm64)
    hinweis "ARM-Architektur ($(uname -m)) — die verumind-Images werden für x86-64 gebaut."
    ;;
  *) mangel "Unerwartete Architektur: $(uname -m)" "Die Programm-Images gibt es für x86-64." ;;
esac

if [ -r /etc/os-release ]; then
  . /etc/os-release 2>/dev/null
  ok "Betriebssystem: ${PRETTY_NAME:-unbekannt}"
fi

if [ "$(id -u)" = "0" ]; then
  ok "Als root ausgeführt"
else
  hinweis "Nicht als root — einige Prüfungen (belegte Ports) können unvollständig sein."
fi

# ── 2. Docker und Compose ────────────────────────────────────────────────────
titel "2. Docker"

if command -v docker >/dev/null 2>&1; then
  DV="$(docker version --format '{{.Server.Version}}' 2>/dev/null)"
  if [ -z "$DV" ]; then
    mangel "Docker ist installiert, antwortet aber nicht" \
      "Läuft der Dienst? Prüfen mit: systemctl status docker"
  else
    ok "Docker $DV"
    if docker compose version >/dev/null 2>&1; then
      ok "Docker Compose $(docker compose version --short 2>/dev/null)"
    else
      mangel "Docker Compose (v2) fehlt" \
        "Der Hub braucht 'docker compose' als Plugin, nicht das alte 'docker-compose'. Paket: docker-compose-plugin"
    fi
  fi
else
  mangel "Docker ist nicht installiert" \
    "Installationsschritte stehen in der Kundenanleitung, Abschnitt 3."
fi

# ── 3. Ausstattung ───────────────────────────────────────────────────────────
titel "3. Ausstattung"

KERNE="$(nproc 2>/dev/null || echo 0)"
if [ "$KERNE" -ge "$MIN_KERNE" ]; then
  ok "$KERNE CPU-Kerne (mindestens $MIN_KERNE)"
else
  mangel "Nur $KERNE CPU-Kern(e), gefordert sind $MIN_KERNE" \
    "Der Hub startet mehrere Arbeitsprozesse; mit einem Kern wird das Portal zäh."
fi

RAM_MB="$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo 2>/dev/null || echo 0)"
if [ "$RAM_MB" -ge "$MIN_RAM_MB" ]; then
  ok "$RAM_MB MB Arbeitsspeicher (mindestens 4 GB)"
else
  mangel "Nur $RAM_MB MB Arbeitsspeicher, gefordert sind 4 GB" \
    "Datenbank und Anwendung laufen auf demselben Server. Mit weniger bricht der Dienst unter Last ab."
fi

# Zielordner der Installation, sonst das Wurzelverzeichnis.
PLATTE_ZIEL=/opt
[ -d "$PLATTE_ZIEL" ] || PLATTE_ZIEL=/
FREI_GB="$(df -BG --output=avail "$PLATTE_ZIEL" 2>/dev/null | tail -1 | tr -dc '0-9')"
[ -z "$FREI_GB" ] && FREI_GB=0
if [ "$FREI_GB" -ge "$MIN_PLATTE_GB" ]; then
  ok "$FREI_GB GB frei auf $PLATTE_ZIEL (mindestens $MIN_PLATTE_GB GB)"
else
  mangel "Nur $FREI_GB GB frei auf $PLATTE_ZIEL, gefordert sind $MIN_PLATTE_GB GB" \
    "Programm-Images, Datenbank und die automatischen Sicherungen vor jedem Update brauchen den Platz."
fi

# ── 4. Ports ─────────────────────────────────────────────────────────────────
titel "4. Ports 80 und 443"

port_belegt() {
  if command -v ss >/dev/null 2>&1; then
    ss -lnt 2>/dev/null | awk '{print $4}' | grep -qE "[:.]$1\$"
  elif command -v netstat >/dev/null 2>&1; then
    netstat -lnt 2>/dev/null | awk '{print $4}' | grep -qE "[:.]$1\$"
  else
    return 2
  fi
}

# Läuft hier schon ein Hub? Dann hält SEIN Caddy die beiden Ports, und das ist
# kein Mangel, sondern der Normalzustand. Ohne diese Unterscheidung liest sich
# eine Wiederholungsprüfung auf einer laufenden Installation wie eine
# Mängelliste — gemessen am 02.08.2026 auf test.verumind.de.
HUB_LAEUFT=0
if command -v docker >/dev/null 2>&1 \
   && [ -n "$(docker ps -q --filter 'name=verumind-hub-caddy' 2>/dev/null)" ]; then
  HUB_LAEUFT=1
fi

for p in 80 443; do
  port_belegt "$p"
  case $? in
    0) if [ "$HUB_LAEUFT" = "1" ]; then
         ok "Port $p wird vom bereits laufenden verumind Hub gehalten"
       else
         BELEGER="$(ss -lntp 2>/dev/null | grep -E "[:.]$p " | grep -oE 'users:\(\("[^"]+' | head -1 | sed 's/.*"//')"
         mangel "Port $p ist belegt${BELEGER:+ (durch $BELEGER)}" \
           "Der Hub braucht beide Ports selbst. Läuft dort ein Apache oder nginx, muss er vorher weichen."
       fi ;;
    1) ok "Port $p ist frei" ;;
    *) hinweis "Port $p konnte nicht geprüft werden (weder ss noch netstat vorhanden)." ;;
  esac
done

# ── 5. Namensauflösung ───────────────────────────────────────────────────────
titel "5. Zeigt $DOMAIN auf diesen Server?"

eigene_adressen() {
  if command -v ip >/dev/null 2>&1; then
    ip -o addr show scope global 2>/dev/null | awk '{print $4}' | cut -d/ -f1
  else
    hostname -I 2>/dev/null | tr ' ' '\n'
  fi
}

aufloesen() {
  if command -v getent >/dev/null 2>&1; then
    getent ahostsv4 "$1" 2>/dev/null | awk '{print $1}' | sort -u
  elif command -v dig >/dev/null 2>&1; then
    dig +short A "$1" 2>/dev/null
  fi
}

DNS_ADRESSEN="$(aufloesen "$DOMAIN")"
if [ -z "$DNS_ADRESSEN" ]; then
  mangel "$DOMAIN lässt sich nicht auflösen" \
    "Der DNS-Eintrag fehlt oder ist noch nicht verbreitet. Ohne ihn stellt Let's Encrypt kein Zertifikat aus."
else
  EIGENE="$(eigene_adressen)"
  TREFFER=0
  for a in $DNS_ADRESSEN; do
    for e in $EIGENE; do [ "$a" = "$e" ] && TREFFER=1; done
  done
  if [ "$TREFFER" = "1" ]; then
    ok "$DOMAIN zeigt auf diesen Server ($(echo "$DNS_ADRESSEN" | tr '\n' ' '))"
  else
    mangel "$DOMAIN zeigt auf $(echo "$DNS_ADRESSEN" | tr '\n' ' '), nicht auf diesen Server" \
      "Eigene Adressen: $(echo "$EIGENE" | tr '\n' ' '). Steht ein Reverse-Proxy davor, ist das in Ordnung — sonst schlägt die Zertifikatsausstellung fehl."
  fi
fi

# ── 6. Ausgehende Erreichbarkeit ─────────────────────────────────────────────
titel "6. Ausgehende Verbindungen (HTTPS)"

if command -v curl >/dev/null 2>&1; then
  for z in $ZIELE; do
    # Nicht der Inhalt zählt, sondern dass überhaupt eine HTTPS-Verbindung
    # zustande kommt. Manche Ziele antworten auf „/" mit 401 oder 404 — das ist
    # eine Antwort und damit der Beweis, dass die Firewall offen ist.
    CODE="$(curl -s --max-time 12 -o /dev/null -w '%{http_code}' "https://$z" 2>/dev/null)"
    if [ -n "$CODE" ] && [ "$CODE" != "000" ]; then
      ok "$z erreichbar (Antwort $CODE)"
    else
      case "$z" in
        ghcr.io|pkg-containers*) FOLGE="schlägt jedes Update fehl" ;;
        updates.*)               FOLGE="meldet die Versionsprüfung nie ein Update" ;;
        acme-*)                  FOLGE="gibt es kein HTTPS-Zertifikat" ;;
        *)                       FOLGE="schlägt ein Teil des Betriebs fehl" ;;
      esac
      mangel "$z NICHT erreichbar" \
        "Ausgehend auf Port 443 in der Firewall freigeben — sonst $FOLGE."
    fi
  done
else
  mangel "curl ist nicht installiert" "Ohne curl lässt sich die Erreichbarkeit nicht prüfen (Paket: curl)."
fi

# ── 7. Registry-Token ────────────────────────────────────────────────────────
titel "7. Zugang zur Programm-Registry"

if [ "$OHNE_TOKEN" = "1" ]; then
  hinweis "Token-Prüfung übersprungen (--ohne-token)."
elif ! command -v docker >/dev/null 2>&1; then
  hinweis "Ohne Docker nicht prüfbar."
else
  printf "  Registry-Token von verumind (Eingabe bleibt unsichtbar, leer = überspringen):\n  > "
  stty -echo 2>/dev/null; read -r TOKEN; stty echo 2>/dev/null; printf "\n"
  if [ -z "$TOKEN" ]; then
    hinweis "Kein Token angegeben — der Zugang wurde NICHT geprüft."
  elif printf '%s' "$TOKEN" | docker login "$REGISTRY_HOST" -u verumind-deploy --password-stdin >/dev/null 2>&1; then
    ok "Token gültig — Anmeldung an $REGISTRY_HOST erfolgreich"
    hinweis "Die Anmeldung bleibt bestehen; install.sh braucht sie ohnehin."
  else
    mangel "Anmeldung an $REGISTRY_HOST abgelehnt" \
      "Token abgelaufen, vertippt oder entzogen. Bei verumind ein neues anfordern."
  fi
fi

# ── Ergebnis ─────────────────────────────────────────────────────────────────
printf "\n${FETT}────────────────────────────────────────────────────────────${AUS}\n"
if [ "$FEHLER" = "0" ]; then
  printf "${GRUEN}${FETT}Dieser Server ist für die Installation geeignet.${AUS}\n"
  [ "$WARNUNGEN" -gt 0 ] && printf "(%s Hinweis(e) oben — kein Hindernis, aber lesenswert.)\n" "$WARNUNGEN"
  # Der Befehl muss zu Abschnitt 7 der INSTALLATION.md passen. Hier stand
  # `sh install.sh` — install.sh braucht aber Bash, und auf Ubuntu ist /bin/sh
  # die Dash. Wer diesem Hinweis folgte, sah beim Passwort einen Abbruch mit
  # „read: Illegal option -s". Gefunden am 03.08.2026 im Installationstest.
  printf "\nNächster Schritt:  sudo ./install.sh\n\n"
  exit 0
fi

printf "${ROT}${FETT}Dieser Server ist noch NICHT geeignet. Es fehlt:${AUS}\n%s\n" "$MAENGEL"
printf "\nBitte diese Punkte beheben und die Prüfung wiederholen.\n"
printf "Bei Rückfragen: info@verumind.de — am besten diese Ausgabe mitschicken.\n\n"
exit 1
