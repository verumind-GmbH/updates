#!/usr/bin/env bash
# ==============================================================================
# Verumind Hub — Erstinstallation (Paket K / Phase 1).
#
# Ein Kommando für die Kunden-IT: prüft Docker, erzeugt ALLE Secrets automatisch,
# fragt nur die wenigen kundenspezifischen Werte ab, lädt die fertigen Images aus
# der GitHub Container Registry und startet den Stack. Baut NICHTS selbst.
#
#   sudo ./install.sh
#
# Voraussetzungen (Kunden-IT): Linux-Server mit öffentlicher IP, Docker + Compose-
# Plugin, Ports 80/443 offen, und eine (Sub-)Domain, deren DNS-A-Record BEREITS auf
# die Server-IP zeigt (sonst schlägt die HTTPS-Zertifikatsausstellung fehl).
# ==============================================================================
set -euo pipefail

COMPOSE_FILE="docker-compose.prod.yml"
ENV_FILE=".env"
# Zentrale Versionsquelle von verumind — daraus ermittelt der Installer selbst, welche
# Version aktuell ist. Der Kunde muss keine Versionsnummer kennen.
MANIFEST_URL="https://verumind.de/wp-content/updates/latest.json"

say()  { printf '\033[1;36m%s\033[0m\n' "$*"; }
ok()   { printf '\033[1;32m✓ %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33m! %s\033[0m\n' "$*"; }
die()  { printf '\033[1;31m✗ %s\033[0m\n' "$*" >&2; exit 1; }

# ── 1. Vorbedingungen ─────────────────────────────────────────────────────────
say "Verumind Hub — Installation"
[ -f "$COMPOSE_FILE" ] || die "$COMPOSE_FILE fehlt — im Install-Verzeichnis ausführen."
[ -f "Caddyfile" ] || die "Caddyfile fehlt — gehört ins Install-Paket."
command -v docker >/dev/null 2>&1 || die "Docker ist nicht installiert. Bitte Docker + Compose-Plugin installieren (https://docs.docker.com/engine/install/)."
docker compose version >/dev/null 2>&1 || die "Docker Compose-Plugin fehlt (docker compose v2)."
command -v openssl >/dev/null 2>&1 || die "openssl fehlt (zum Erzeugen der Secrets)."
command -v curl >/dev/null 2>&1 || die "curl fehlt (zum Ermitteln der aktuellen Version)."
ok "Docker + Compose gefunden"

# ── 2. Bestehende Installation nicht überschreiben ────────────────────────────
if [ -f "$ENV_FILE" ]; then
  warn "$ENV_FILE existiert bereits — das sieht nach einer bestehenden Installation aus."
  warn "Für ein UPDATE nutze bitte das Update-Kommando, nicht install.sh."
  read -r -p "Trotzdem NEU einrichten und $ENV_FILE überschreiben? (tippe 'ja'): " conf
  [ "$conf" = "ja" ] || die "Abgebrochen — bestehende .env bleibt unangetastet."
fi

# ── 3. Eingaben (nur das kundenspezifische Minimum) ───────────────────────────
say "Ein paar Angaben:"
read -r -p "  Domain des Portals (z. B. hub.kunde.de): " DOMAIN
[ -n "$DOMAIN" ] || die "Domain ist Pflicht."
read -r -p "  E-Mail für Let's-Encrypt-Zertifikat: " ACME_EMAIL
read -r -p "  Admin-E-Mail (erster Login): " SEED_ADMIN_EMAIL
read -r -s -p "  Admin-Passwort (Eingabe verborgen): " SEED_ADMIN_PASSWORD; echo
[ -n "$SEED_ADMIN_PASSWORD" ] || die "Admin-Passwort ist Pflicht."
echo
say "Zugang zur Programm-Registry:"
# Organisation und Bezugskonto sind FESTE Werte von verumind — für jede Installation
# gleich, kein Kundenwissen nötig. Der Kunde gibt ausschließlich sein Token ein.
# Für Sonderfälle (eigene Spiegel-Registry) per Umgebungsvariable überschreibbar:
#   VERUMIND_REGISTRY_ORG=… VERUMIND_REGISTRY_USER=… ./install.sh
REG_ORG="${VERUMIND_REGISTRY_ORG:-verumind-gmbh}"
REG_USER="${VERUMIND_REGISTRY_USER:-verumind-deploy}"
read -r -s -p "  Registry-Token (von verumind erhalten): " REG_TOKEN; echo
[ -n "$REG_TOKEN" ] || die "Registry-Token ist Pflicht (zum Laden der Images)."
# ── Version automatisch ermitteln ─────────────────────────────────────────────
# Bewusst KEINE Vorgabe „latest": Der Tag `latest` würde als Versionsangabe in der
# Konfiguration landen, und die Instanz meldete später „Version: latest" — damit
# funktioniert die Update-Erkennung nicht mehr (kein Vergleich mit einer Nummer
# möglich). Deshalb wird immer eine konkrete Version festgeschrieben.
echo
say "Ermittle die aktuelle Version…"
VERUMIND_VERSION="$(curl -fsSL --max-time 10 "$MANIFEST_URL" 2>/dev/null \
  | tr -d '\n' | sed -n 's/.*"version"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p')"
# Eingaben wie „ja" dürfen NICHT als Versionsnummer durchgehen — sonst wird ein
# Image-Tag „:ja" gesucht und die Installation bricht mit einer unverständlichen
# Registry-Meldung ab. Deshalb Format prüfen und notfalls erneut fragen.
is_version() { printf '%s' "$1" | grep -qE '^[0-9]+\.[0-9]+\.[0-9]+([.+-][0-9A-Za-z.-]+)?$'; }

if [ -n "$VERUMIND_VERSION" ]; then
  ok "Aktuelle Version: $VERUMIND_VERSION"
  while true; do
    read -r -p "  [Enter] = Version $VERUMIND_VERSION installieren (oder andere Versionsnummer eingeben): " V_IN
    [ -z "$V_IN" ] && break
    V_IN="${V_IN#v}" # führendes „v" tolerieren (v1.4.0 → 1.4.0)
    if is_version "$V_IN"; then VERUMIND_VERSION="$V_IN"; break; fi
    warn "\"$V_IN\" ist keine Versionsnummer. Erwartet wird z. B. 1.4.0 — oder einfach [Enter] für $VERUMIND_VERSION."
  done
else
  warn "Die aktuelle Version konnte nicht automatisch ermittelt werden (kein Internetzugang?)."
  while true; do
    read -r -p "  Zu installierende Version (von verumind erhalten, z. B. 1.4.0): " VERUMIND_VERSION
    VERUMIND_VERSION="${VERUMIND_VERSION#v}"
    is_version "$VERUMIND_VERSION" && break
    warn "Bitte eine Versionsnummer im Format 1.4.0 eingeben."
  done
fi

# ── 4. Secrets erzeugen ───────────────────────────────────────────────────────
say "Erzeuge Secrets…"
gen() { openssl rand -hex 32; }
POSTGRES_PASSWORD="$(gen)"
JWT_ACCESS_SECRET="$(gen)"
JWT_REFRESH_SECRET="$(gen)"
TWOFA_ENCRYPTION_KEY="$(gen)"
CRM_ENCRYPTION_KEY="$(gen)"
N8N_WEBHOOK_SECRET="$(gen)"
ok "Secrets erzeugt (openssl)"

# ── 5. .env schreiben ─────────────────────────────────────────────────────────
umask 077 # .env nur für den Eigentümer lesbar
cat > "$ENV_FILE" <<EOF
# Erzeugt von install.sh — enthält Secrets, NICHT teilen/committen.
VERUMIND_VERSION=${VERUMIND_VERSION}
VERUMIND_REGISTRY=ghcr.io/${REG_ORG}

POSTGRES_DB=verumind_hub
POSTGRES_USER=verumind
POSTGRES_PASSWORD=${POSTGRES_PASSWORD}

JWT_ACCESS_SECRET=${JWT_ACCESS_SECRET}
JWT_REFRESH_SECRET=${JWT_REFRESH_SECRET}
JWT_ACCESS_EXPIRES_IN=15m
JWT_REFRESH_EXPIRES_IN=7d
TWOFA_ENCRYPTION_KEY=${TWOFA_ENCRYPTION_KEY}
CRM_ENCRYPTION_KEY=${CRM_ENCRYPTION_KEY}

SEED_ADMIN_EMAIL=${SEED_ADMIN_EMAIL}
SEED_ADMIN_PASSWORD=${SEED_ADMIN_PASSWORD}

DOMAIN=${DOMAIN}
ACME_EMAIL=${ACME_EMAIL}
ACME_CA=
APP_URL=https://${DOMAIN}

# Versionsquelle für die Update-Prüfung (zentral von verumind gepflegt). Damit meldet
# das Portal automatisch „Update verfügbar", sobald eine neuere Version erscheint.
VERUMIND_UPDATE_MANIFEST_URL=${MANIFEST_URL}

SMTP_HOST=
SMTP_PORT=587
SMTP_USER=
SMTP_PASSWORD=
SMTP_FROM=Verumind Hub <noreply@${DOMAIN}>

N8N_LEADGEN_WEBHOOK_URL=
N8N_WEBHOOK_SECRET=${N8N_WEBHOOK_SECRET}

LEADGEN_ENRICH_PERSONS=false
SEED_TEST_LEADS=false
AUDIT_LOG_RETENTION_DAYS=90
LEADGEN_ENRICH_CONCURRENCY=2
LEADGEN_ENRICH_STUCK_MINUTES=10
EOF
ok ".env geschrieben (Rechte 600)"

# ── 6. Images laden + starten ─────────────────────────────────────────────────
say "Melde an der Registry an…"
echo "$REG_TOKEN" | docker login ghcr.io -u "$REG_USER" --password-stdin >/dev/null \
  || die "Registry-Login fehlgeschlagen — Token/Benutzer prüfen."
ok "Registry-Login ok"

say "Lade Images (kann beim ersten Mal dauern)…"
docker compose -f "$COMPOSE_FILE" pull
say "Starte den Stack…"
docker compose -f "$COMPOSE_FILE" up -d

# ── 7. Auf Bereitschaft warten ────────────────────────────────────────────────
say "Warte auf Bereitschaft des Backends…"
ready=0
for i in $(seq 1 60); do
  if docker compose -f "$COMPOSE_FILE" exec -T backend \
       node -e "require('http').get('http://127.0.0.1:3000/health',r=>process.exit(r.statusCode===200?0:1)).on('error',()=>process.exit(1))" >/dev/null 2>&1; then
    ready=1; break
  fi
  sleep 3
done

echo
if [ "$ready" = "1" ]; then
  ok "Installation abgeschlossen."
  say "Portal:  https://${DOMAIN}"
  say "Login:   ${SEED_ADMIN_EMAIL}  (Passwort wie eingegeben)"
  warn "Hinweis: Das HTTPS-Zertifikat kann nach dem ersten Aufruf ein paar Sekunden brauchen."
  warn "Bitte nach dem ersten Login das Admin-Passwort ändern."
else
  warn "Der Stack läuft, aber das Backend meldete sich nicht rechtzeitig als bereit."
  warn "Status prüfen:  docker compose -f ${COMPOSE_FILE} ps"
  warn "Logs ansehen:   docker compose -f ${COMPOSE_FILE} logs backend"
fi
