#!/usr/bin/env bash
# ==============================================================================
# verumind Hub — Erstinstallation (Paket K / Phase 1).
#
# Ein Kommando für die Kunden-IT: prüft Docker, erzeugt ALLE Secrets automatisch,
# fragt nur die wenigen kundenspezifischen Werte ab, lädt die fertigen Images aus
# der GitHub Container Registry und startet den Stack. Baut NICHTS selbst.
#
#   sudo ./install.sh
#
# Voraussetzungen (Kunden-IT): Linux-Server mit öffentlicher IP, Docker + Compose-
# Plugin, Ports 80/443 offen, und eine (Sub-)Domain, deren DNS-A-Record BEREITS auf
# die Server-IP zeigt (sonst schlägt die HTTPS-Zertifikatsausstellung fehl).
# ==============================================================================

# ── ALS ALLERERSTES: Läuft das hier überhaupt unter Bash? ────────────────────
#
# Dieses Skript braucht Bash. Die Passworteingabe verbirgt sich mit `read -s`,
# und das kennt die Dash nicht, die auf Ubuntu und Debian als /bin/sh dient.
#
# ANLASS, 03.08.2026: Beim ersten vollständigen Installationstest brach die
# Installation mit `install.sh: 176: read: Illegal option -s` ab — mitten in der
# Passwortabfrage, ohne Hinweis darauf, was zu tun ist. Der Aufruf war
# `sh install.sh`, und der stand so in unserer eigenen Ausgabe: pruefe-server.sh
# nannte ihn als nächsten Schritt, die Anleitung druckte diese Ausgabe ab.
# Drei Bausteine, jeder für sich harmlos, zusammen eine Falle. Für einen Kunden
# wäre das der erste Kontakt mit dem Produkt gewesen.
#
# WARUM ABBRUCH UND NICHT SELBSTNEUSTART: Ein `exec bash "$0"` wäre bequemer,
# würde den falschen Aufruf aber funktionieren lassen — und damit verdecken, dass
# irgendwo wieder ein falscher Befehl ausgegeben wird. Die Meldung nennt den
# richtigen Befehl; das kostet fünf Sekunden und bringt ihn bei.
#
# Diese Prüfung steht VOR `set -euo pipefail` und vor jeder Ausgabe. Sie muss
# unter jeder Shell laufen, ist deshalb streng POSIX gehalten.
if [ -z "${BASH_VERSION:-}" ]; then
  printf '\n  Dieses Skript braucht Bash und wurde mit einer anderen Shell gestartet.\n\n' >&2
  printf '  Bitte so aufrufen:\n\n' >&2
  printf '      sudo ./install.sh\n\n' >&2
  printf '  Meldet das „Permission denied", fehlt das Ausführungsrecht:\n\n' >&2
  printf '      chmod +x install.sh\n\n' >&2
  printf '  Es wurde nichts verändert.\n\n' >&2
  exit 1
fi

set -euo pipefail

# Basis und Kundendatei (ADR-003, I4, 20.11.2026). Die Basis gehört verumind und
# wird mit jedem Update ersetzt; Anpassungen der Installation stehen in der
# Kundendatei, die kein Update anfasst. `COMPOSE_FILE` in der .env verbindet
# beide. Bewusst nicht unter dem Namen COMPOSE_FILE als Variable dieses Skripts:
# Docker Compose liest diesen Namen selbst.
BASISDATEI="docker-compose.prod.yml"
KUNDENDATEI="docker-compose.kunde.yml"
ENV_FILE=".env"
# Muss wortgleich mit KUNDENDATEI_INHALT in updater/updater.sh sein; das prüft
# backend/src/update/kundendatei.spec.ts.
KUNDENDATEI_INHALT='# Anpassungen dieser Installation (ADR-003). Diese Datei gehört Ihnen:
# Ein Update ändert sie nie. Die Basis docker-compose.prod.yml gehört verumind
# und wird mit jedem Update ersetzt; ändern Sie sie nicht.
#
# Ein Wert hier ergänzt oder ersetzt den der Basis. Listen wie `ports` werden
# angehängt; wer einen Port ERSETZEN will, schreibt `ports: !override [...]`.
services: {}'
# Zentrale Versionsquelle von verumind — daraus ermittelt der Installer selbst, welche
# Version aktuell ist. Der Kunde muss keine Versionsnummer kennen.
MANIFEST_URL="https://updates.verumind.de/latest.json"

say()  { printf '\033[1;36m%s\033[0m\n' "$*"; }
ok()   { printf '\033[1;32m✓ %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33m! %s\033[0m\n' "$*"; }
die()  { printf '\033[1;31m✗ %s\033[0m\n' "$*" >&2; exit 1; }

# ── 1. Vorbedingungen ─────────────────────────────────────────────────────────
say "verumind Hub — Installation"
[ -f "$BASISDATEI" ] || die "$BASISDATEI fehlt — im Install-Verzeichnis ausführen."
[ -f "Caddyfile" ] || die "Caddyfile fehlt — gehört ins Install-Paket."
command -v docker >/dev/null 2>&1 || die "Docker ist nicht installiert. Bitte Docker + Compose-Plugin installieren (https://docs.docker.com/engine/install/)."
docker compose version >/dev/null 2>&1 || die "Docker Compose-Plugin fehlt (docker compose v2)."
command -v openssl >/dev/null 2>&1 || die "openssl fehlt (zum Erzeugen der Secrets)."
command -v curl >/dev/null 2>&1 || die "curl fehlt (zum Ermitteln der aktuellen Version)."
ok "Docker + Compose gefunden"

# ── 2. Bestehende Installation erkennen ───────────────────────────────────────
#
# WARUM DAS SO AUSFÜHRLICH IST: Hier stand eine Rückfrage, die bei „ja" alle
# Geheimnisse NEU erzeugte. Das ist der teuerste Fehler, den diese Datei machen
# kann — und er trifft genau den, der ihn am wenigsten erwartet:
#
#   • POSTGRES_PASSWORD neu  → die Datenbank im Volume kennt es nicht mehr,
#                              das Backend kommt nicht mehr an seine Daten
#   • CRM_ENCRYPTION_KEY neu → alle gespeicherten CRM-Zugänge sind unlesbar
#   • TWOFA_ENCRYPTION_KEY neu → niemand mit Zwei-Faktor kann sich mehr anmelden
#
# Diese Verluste sind ENDGÜLTIG: Die alten Schlüssel standen nur in der .env, die
# gerade überschrieben wurde. Deshalb gibt es diesen Weg nicht mehr — auch nicht
# mit Bestätigung. Wer im Störungsfall „nochmal neu installieren" versucht, darf
# damit nichts zerstören können.
#
# ZWEI SIGNALE, unabhängig voneinander:
#   1. eine vorhandene .env
#   2. ein vorhandenes Datenbank-Volume — das STÄRKERE Signal, denn es kann eine
#      .env fehlen (gelöscht, verschoben) und trotzdem Daten geben.
POSTGRES_VOLUME="verumind_hub_postgres"

hat_env=false
hat_daten=false
[ -f "$ENV_FILE" ] && hat_env=true
docker volume inspect "$POSTGRES_VOLUME" >/dev/null 2>&1 && hat_daten=true

# Der gefährlichste Zustand: Daten da, Schlüssel weg. Würden hier neue Geheimnisse
# erzeugt, wäre die Datenbank unerreichbar und alles Verschlüsselte verloren.
# Dieser Fall wird NICHT durch eine Rückfrage entschärft — er wird abgebrochen.
if [ "$hat_daten" = true ] && [ "$hat_env" = false ]; then
  echo
  die "Es gibt bereits eine Datenbank dieser Installation ($POSTGRES_VOLUME), aber keine $ENV_FILE.

Die $ENV_FILE enthält die Schlüssel, mit denen diese Daten gelesen werden. Ohne sie
kommt niemand an die Daten heran — auch eine Neuinstallation nicht.

BITTE NICHT weitermachen, sondern zuerst prüfen:
  • Liegt eine Sicherung der $ENV_FILE vor? Suchen Sie im Installationsverzeichnis
    nach Dateien mit dem Namen '$ENV_FILE.vorher-…'.
  • Haben Sie eine Sicherung des ganzen Servers oder des Verzeichnisses?

Legen Sie die $ENV_FILE zurück und starten Sie dieses Skript erneut.
Finden Sie keine: wenden Sie sich an verumind, BEVOR Sie etwas ändern."
fi

# .env vorhanden → Ergänzungsbetrieb. Alle bereits vergebenen Geheimnisse werden
# übernommen; erzeugt wird nur, was fehlt.
ERGAENZEN=false
if [ "$hat_env" = true ]; then
  ERGAENZEN=true
  echo
  warn "Es gibt bereits eine Installation in diesem Verzeichnis."
  say  "Dieses Skript wird deshalb im Ergänzungsbetrieb ausgeführt:"
  say  "  • Alle bestehenden Schlüssel und Passwörter werden ÜBERNOMMEN."
  say  "  • Nur fehlende Angaben werden ergänzt."
  say  "  • Ihre Daten werden nicht angefasst."
  echo
  say  "Falls Sie stattdessen aktualisieren wollen: Das geht im Portal unter"
  say  "  Einstellungen → Installation → Aktualisierung — nicht mit diesem Skript."
  echo
fi

# Liest einen Wert aus der BESTEHENDEN .env (leer, wenn nicht vorhanden).
# Wird für die Übernahme von Geheimnissen und als Vorbelegung der Eingaben genutzt.
alt_wert() {
  [ -f "$ENV_FILE" ] || return 0
  grep -E "^$1=" "$ENV_FILE" 2>/dev/null | head -1 | cut -d= -f2- || true
}
# Welche Compose-Dateien gelten (ADR-003, I4). Eine neue Installation bekommt
# Basis plus Kundendatei. Im Ergänzungsbetrieb bleibt, was die .env sagt: Hat
# der Update-Dienst schon umgestellt, steht COMPOSE_FILE dort. Fehlt es, stellt
# erst die Umstellung der Infrastruktur im Hub um, nachdem sie die Basis als
# unverändert erkannt hat. Dieses Skript entscheidet das nicht an ihrer Stelle.
if [ "$ERGAENZEN" = true ]; then
  COMPOSE_WERT="$(alt_wert COMPOSE_FILE)"
else
  COMPOSE_WERT="$BASISDATEI:$KUNDENDATEI"
fi
# Docker Compose mit genau diesen Dateien. COMPOSE_FILE wird ausdrücklich
# mitgegeben: Ein in der Sitzung gesetzter Wert ginge sonst der .env vor.
dc() {
  if [ -n "$COMPOSE_WERT" ]; then
    COMPOSE_FILE="$COMPOSE_WERT" docker compose "$@"
  else
    docker compose -f "$BASISDATEI" "$@"
  fi
}
# So steht der Befehl in den Hinweisen. Mit COMPOSE_FILE in der .env genügt
# im Installationsordner ein schlichtes `docker compose`.
if [ -n "$COMPOSE_WERT" ]; then DC_TEXT="docker compose"; else DC_TEXT="docker compose -f $BASISDATEI"; fi

# ── 3. Eingaben (nur das kundenspezifische Minimum) ───────────────────────────
#
# Im Ergänzungsbetrieb sind die bisherigen Werte vorbelegt: [Enter] übernimmt sie.
# Sonst müsste jemand, der das Skript nur wegen eines fehlenden Schlüssels erneut
# ausführt, die Domain fehlerfrei abtippen — und ein Tippfehler dort kostet das
# HTTPS-Zertifikat.
frage() { # frage <Beschriftung> <alter-Wert> → Antwort auf stdout
  local text="$1" alt="$2" eingabe
  if [ -n "$alt" ]; then
    read -r -p "  $text [$alt]: " eingabe
    printf '%s' "${eingabe:-$alt}"
  else
    read -r -p "  $text: " eingabe
    printf '%s' "$eingabe"
  fi
}

say "Ein paar Angaben:"
DOMAIN="$(frage "Domain des Portals (z. B. hub.kunde.de)" "$(alt_wert DOMAIN)")"
[ -n "$DOMAIN" ] || die "Domain ist Pflicht."

# ── Woher kommt das HTTPS-Zertifikat? ────────────────────────────────────────
#
# ANLASS: Bis hierher holte sich der Server sein Zertifikat immer selbst über
# Port 80 bei Let's Encrypt. Das setzt voraus, dass der Server aus dem Internet
# erreichbar ist — und genau das ist bei einer internen Anwendung meist nicht
# der Fall und oft auch nicht gewollt. Beim ersten echten Kunden war Port 80
# nicht offen; der Server bekam kein Zertifikat und konnte gar nichts
# ausliefern, weder über den Namen noch über die IP.
#
# Es wird nichts erzwungen: Wer ein eigenes Zertifikat hat, legt es ab; wer
# keines hat, bekommt weiter den automatischen Weg.
CERT_DIR="$(pwd)/certs"
mkdir -p certs
chmod 755 certs

say ""
say "HTTPS-Zertifikat"
say "  [1] Automatisch über Let's Encrypt — braucht Port 80 aus dem Internet."
say "  [2] Eigenes Zertifikat — kein Port 80 nötig."
say "      Dafür gehören zwei Dateien nach ${CERT_DIR}:"
say "        hub.crt  Zertifikat samt Zwischenzertifikaten (PEM)"
say "        hub.key  privater Schlüssel (PEM, ohne Passwort)"
ZERT_WAHL="$(frage "Auswahl [1/2]" "1")"

if [ "$ZERT_WAHL" = "2" ]; then
  ACME_EMAIL=""
  if [ -s certs/hub.crt ] && [ -s certs/hub.key ]; then
    ok "Eigenes Zertifikat gefunden — es wird verwendet."
  else
    # Kein Abbruch: Das Zertifikat kommt oft erst später von der IT. Die
    # Installation läuft durch, und sobald die Dateien liegen, genügt ein
    # Neustart des Webservers.
    warn "Noch kein Zertifikat unter ${CERT_DIR} — die Installation läuft trotzdem durch."
    warn "Sobald hub.crt und hub.key dort liegen:"
    warn "  ${DC_TEXT} up -d caddy"
  fi
else
  ACME_EMAIL="$(frage "E-Mail für Let's-Encrypt-Zertifikat" "$(alt_wert ACME_EMAIL)")"
fi
SEED_ADMIN_EMAIL="$(frage "Admin-E-Mail (erster Login)" "$(alt_wert SEED_ADMIN_EMAIL)")"

# ── Admin-Passwort ───────────────────────────────────────────────────────────
#
# Es wird NICHT vorbelegt und nie angezeigt. Im Ergänzungsbetrieb genügt [Enter] —
# dann bleibt das bisherige unverändert. Ein bereits angelegtes Konto wird vom
# Seed ohnehin nicht überschrieben.
#
# WARUM HIER GEPRÜFT WIRD: `backend/prisma/seed.ts` legt das Konto an, ohne das
# Passwort gegen die Regeln zu prüfen — es wird direkt gehasht. Ohne die Prüfung
# hier bekäme ein Kunde also ein vierstelliges Admin-Passwort für ein System, das
# aus dem Internet erreichbar ist, und merkte es erst beim ersten Ändern im
# Portal, wo die Regeln greifen.
#
# DIE REGELN MÜSSEN DIESELBEN SEIN wie in `backend/src/auth/password-policy.ts`.
# Zwei Orte, zwei Sprachen — sie können sich nicht gemeinsam ändern. Deshalb
# vergleicht `backend/src/release/passwort-regeln.spec.ts` beide Quellen und
# schlägt an, wenn sie auseinanderlaufen.
PASSWORT_MIN_LAENGE=12

passwort_maengel() {
  local p="$1" m=""
  [ "${#p}" -ge "$PASSWORT_MIN_LAENGE" ] || m="${m}
    • mindestens $PASSWORT_MIN_LAENGE Zeichen (eingegeben: ${#p})"
  printf '%s' "$p" | grep -q '[A-Z]' || m="${m}
    • mindestens ein Großbuchstabe"
  printf '%s' "$p" | grep -q '[a-z]' || m="${m}
    • mindestens ein Kleinbuchstabe"
  printf '%s' "$p" | grep -q '[0-9]' || m="${m}
    • mindestens eine Ziffer"
  printf '%s' "$p" | grep -q '[^A-Za-z0-9]' || m="${m}
    • mindestens ein Sonderzeichen"
  printf '%s' "$m"
}

# Bis zu fünf Anläufe, dann Abbruch. Ein Abbruch beim ersten Tippfehler wäre
# ärgerlich — bis hierher sind schon vier Angaben gemacht, die sonst verloren
# gingen.
PASSWORT_VERSUCHE=5
while :; do
  if [ "$ERGAENZEN" = true ]; then
    read -r -s -p "  Admin-Passwort ([Enter] = unverändert lassen): " SEED_ADMIN_PASSWORD; echo
    if [ -z "$SEED_ADMIN_PASSWORD" ]; then
      SEED_ADMIN_PASSWORD="$(alt_wert SEED_ADMIN_PASSWORD)"
      break   # unverändert übernommen — nicht erneut prüfen
    fi
  else
    read -r -s -p "  Admin-Passwort (mind. $PASSWORT_MIN_LAENGE Zeichen, Eingabe verborgen): " SEED_ADMIN_PASSWORD; echo
  fi

  [ -n "$SEED_ADMIN_PASSWORD" ] || { warn "Admin-Passwort ist Pflicht."; continue; }

  MAENGEL="$(passwort_maengel "$SEED_ADMIN_PASSWORD")"
  [ -z "$MAENGEL" ] && break

  warn "Das Passwort erfüllt die Anforderungen noch nicht:$MAENGEL"
  say "  Beispiel für ein gültiges Passwort: Hafen-Kran-2026!"
  PASSWORT_VERSUCHE=$((PASSWORT_VERSUCHE - 1))
  [ "$PASSWORT_VERSUCHE" -gt 0 ] || die "Zu viele Versuche. Bitte install.sh erneut starten."
done
echo
say "Zugang zur Programm-Registry:"
# Organisation und Bezugskonto sind FESTE Werte von verumind — für jede Installation
# gleich, kein Kundenwissen nötig. Der Kunde gibt ausschließlich sein Token ein.
# Für Sonderfälle (eigene Spiegel-Registry) per Umgebungsvariable überschreibbar:
#   VERUMIND_REGISTRY_ORG=… VERUMIND_REGISTRY_USER=… ./install.sh
REG_ORG="${VERUMIND_REGISTRY_ORG:-verumind-gmbh}"
REG_USER="${VERUMIND_REGISTRY_USER:-verumind-deploy}"

# Der Token wird bewusst NICHT in der .env gespeichert — er geht nur an
# `docker login`, das ihn selbst ablegt. Bei einer Wiederholung hat ihn deshalb
# niemand zur Hand. Besteht bereits eine Anmeldung, ist er entbehrlich:
# [Enter] behält sie.
REG_ANMELDUNG_VORHANDEN=false
if grep -q "ghcr.io" "${DOCKER_CONFIG:-$HOME/.docker}/config.json" 2>/dev/null; then
  REG_ANMELDUNG_VORHANDEN=true
fi

if [ "$REG_ANMELDUNG_VORHANDEN" = true ]; then
  read -r -s -p "  Registry-Token ([Enter] = bestehende Anmeldung behalten): " REG_TOKEN; echo
else
  read -r -s -p "  Registry-Token (von verumind erhalten): " REG_TOKEN; echo
  [ -n "$REG_TOKEN" ] || die "Registry-Token ist Pflicht (zum Laden der Images)."
fi
# ── Version automatisch ermitteln ─────────────────────────────────────────────
# Bewusst KEINE Vorgabe „latest": Der Tag `latest` würde als Versionsangabe in der
# Konfiguration landen, und die Instanz meldete später „Version: latest" — damit
# funktioniert die Update-Erkennung nicht mehr (kein Vergleich mit einer Nummer
# möglich). Deshalb wird immer eine konkrete Version festgeschrieben.
echo
say "Ermittle die aktuelle Version…"

# Liest das Feld `version` der OBERSTEN EBENE aus dem Manifest.
#
# WARUM DAS NICHT MEHR PER TEXTSUCHE GEHT: Hier stand ein sed-Ausdruck mit
# `.*"version"…` — und `.*` ist gierig. Als das Manifest um `rollbackVersions`
# erweitert wurde, in denen jeder Eintrag ebenfalls ein `version`-Feld trägt,
# traf der Ausdruck plötzlich den LETZTEN statt den ersten Treffer: Der
# Installer meldete 0.4.0, während 0.6.2 aktuell war. Ein Neukunde hätte eine
# Version von vier Ausgaben zuvor installiert.
#
# Deshalb: strukturiert lesen, wenn möglich.
#
# `jq` wird NICHT vorausgesetzt. Es ist auf einem frisch aufgesetzten Server
# selten vorinstalliert, und der Installer würde sonst an einer Kleinigkeit
# scheitern, die mit dem Produkt nichts zu tun hat — die bisherigen
# Voraussetzungen sind bewusst auf docker, openssl und curl begrenzt.
#
# Ohne jq greift ein Ausdruck, der gegen dieselbe Falle abgesichert ist:
#   • `grep -o` liefert JEDEN Treffer einzeln statt eines gierigen Gesamtmusters
#   • `head -1` nimmt den ersten — und `version` der obersten Ebene steht im
#     Manifest vor `rollbackVersions`
# Beides zusammen ist unempfindlich gegen weitere Felder, solange das
# Versionsfeld zuerst kommt. Die Formatprüfung darunter fängt ab, was trotzdem
# durchrutscht.
manifest_version() {
  local roh="$1"
  if command -v jq >/dev/null 2>&1; then
    printf '%s' "$roh" | jq -r '.version // empty' 2>/dev/null
    return
  fi
  printf '%s' "$roh" \
    | tr -d '\n' \
    | grep -o '"version"[[:space:]]*:[[:space:]]*"[^"]*"' \
    | head -1 \
    | sed 's/.*"\([^"]*\)"$/\1/'
}

MANIFEST_ROH="$(curl -fsSL --max-time 10 "$MANIFEST_URL" 2>/dev/null || true)"
VERUMIND_VERSION="$(manifest_version "$MANIFEST_ROH")"
# Eingaben wie „ja" dürfen NICHT als Versionsnummer durchgehen — sonst wird ein
# Image-Tag „:ja" gesucht und die Installation bricht mit einer unverständlichen
# Registry-Meldung ab. Deshalb Format prüfen und notfalls erneut fragen.
is_version() { printf '%s' "$1" | grep -qE '^[0-9]+\.[0-9]+\.[0-9]+([.+-][0-9A-Za-z.-]+)?$'; }

if [ -n "$VERUMIND_VERSION" ]; then
  ok "Aktuelle Version: $VERUMIND_VERSION"
  while true; do
    read -r -p "  [Enter] = Version $VERUMIND_VERSION installieren (oder andere Versionsnummer eingeben): " V_IN
    [ -z "$V_IN" ] && break
    V_IN="${V_IN#v}" # führendes „v" tolerieren (v1.4.0 → 1.4.0)
    if is_version "$V_IN"; then VERUMIND_VERSION="$V_IN"; break; fi
    warn "\"$V_IN\" ist keine Versionsnummer. Erwartet wird z. B. 1.4.0 — oder einfach [Enter] für $VERUMIND_VERSION."
  done
else
  warn "Die aktuelle Version konnte nicht automatisch ermittelt werden (kein Internetzugang?)."
  while true; do
    read -r -p "  Zu installierende Version (von verumind erhalten, z. B. 1.4.0): " VERUMIND_VERSION
    VERUMIND_VERSION="${VERUMIND_VERSION#v}"
    is_version "$VERUMIND_VERSION" && break
    warn "Bitte eine Versionsnummer im Format 1.4.0 eingeben."
  done
fi

# ── 4. Secrets: bestehende übernehmen, nur fehlende erzeugen ──────────────────
#
# Der Kern der Absicherung. `uebernehmen_oder_erzeugen` liefert IMMER den bereits
# vergebenen Wert, wenn es einen gibt. Ein Geheimnis, mit dem Daten verschlüsselt
# wurden, darf sich nie ändern — sonst sind die Daten unlesbar.
#
# Fehlende Werte werden ergänzt. Genau das braucht eine spätere Erweiterung: Kommt
# ein Modul mit einem neuen Schlüssel dazu, erzeugt ein erneuter Lauf ihn, ohne
# irgendetwas Bestehendes anzufassen.
gen() { openssl rand -hex 32; }

# Bewusst OHNE Zähler in dieser Funktion: Sie wird in einer Kommandoersetzung
# aufgerufen und läuft damit in einer Subshell — eine dort hochgezählte Variable
# wäre außerhalb wieder null. Gezählt wird deshalb weiter unten getrennt.
uebernehmen_oder_erzeugen() {
  local vorhanden
  vorhanden="$(alt_wert "$1")"
  if [ -n "$vorhanden" ]; then
    printf '%s' "$vorhanden"
  else
    gen
  fi
}

if [ "$ERGAENZEN" = true ]; then
  say "Prüfe vorhandene Secrets…"
else
  say "Erzeuge Secrets…"
fi

POSTGRES_PASSWORD="$(uebernehmen_oder_erzeugen POSTGRES_PASSWORD)"
JWT_ACCESS_SECRET="$(uebernehmen_oder_erzeugen JWT_ACCESS_SECRET)"
JWT_REFRESH_SECRET="$(uebernehmen_oder_erzeugen JWT_REFRESH_SECRET)"
TWOFA_ENCRYPTION_KEY="$(uebernehmen_oder_erzeugen TWOFA_ENCRYPTION_KEY)"
CRM_ENCRYPTION_KEY="$(uebernehmen_oder_erzeugen CRM_ENCRYPTION_KEY)"
N8N_WEBHOOK_SECRET="$(uebernehmen_oder_erzeugen N8N_WEBHOOK_SECRET)"

# Nachträglich zählen, was aus der alten Datei kam — nur für die Meldung.
#
# Bewusst mit if/fi statt `[ … ] && …`: Bei aktivem `set -e` liefert ein nicht
# zutreffendes `&&` den Status 1. Trifft das in der LETZTEN Schleifenrunde zu, ist
# das auch der Status der Schleife — und das Skript bricht mitten in der
# Installation ab. Ein Fehler, den weder `bash -n` noch ein Blick auf die Zeile
# zeigt, sondern erst der Lauf mit vollständiger .env.
uebernommen=0
for s in POSTGRES_PASSWORD JWT_ACCESS_SECRET JWT_REFRESH_SECRET \
         TWOFA_ENCRYPTION_KEY CRM_ENCRYPTION_KEY N8N_WEBHOOK_SECRET; do
  if [ -n "$(alt_wert "$s")" ]; then
    uebernommen=$((uebernommen + 1))
  fi
done
erzeugt=$((6 - uebernommen))

if [ "$ERGAENZEN" = true ]; then
  ok "Secrets: $uebernommen übernommen, $erzeugt neu erzeugt"
else
  ok "Secrets erzeugt (openssl)"
fi

# ── 5. .env schreiben ─────────────────────────────────────────────────────────
umask 077 # .env nur für den Eigentümer lesbar

# SICHERUNG VOR JEDEM SCHREIBEN — die eigentliche Rettungsleine.
#
# Die Übernahme oben verhindert den Verlust bereits. Diese Sicherung ist die
# zweite Schicht für den Fall, dass in dieser Datei später doch ein Fehler
# steckt: Solange die alte .env danebenliegt, sind die Schlüssel nicht weg.
#
# Sie bleibt bewusst LIEGEN und wird nie automatisch gelöscht. Ein paar Kilobyte
# gegen einen unwiederbringlichen Verlust ist kein Abwägen wert.
if [ -f "$ENV_FILE" ]; then
  SICHERUNG="${ENV_FILE}.vorher-$(date +%Y%m%d-%H%M%S)"
  cp -p "$ENV_FILE" "$SICHERUNG"
  chmod 600 "$SICHERUNG"
  ok "Bestehende $ENV_FILE gesichert: $SICHERUNG"
fi

# Leer, wenn eine bestehende Installation noch nicht umgestellt ist (siehe oben).
COMPOSE_ZEILE=""
[ -n "$COMPOSE_WERT" ] && COMPOSE_ZEILE="COMPOSE_FILE=${COMPOSE_WERT}"

cat > "$ENV_FILE" <<EOF
# Erzeugt von install.sh — enthält Secrets, NICHT teilen/committen.
VERUMIND_VERSION=${VERUMIND_VERSION}
${COMPOSE_ZEILE}
# L1 — Wächter-Version festschreiben statt ":latest".
#
# Ohne diese Zeile läuft der Wächter auf einer beweglichen Marke: Zwei
# Installationen desselben Stands können verschiedene Fassungen fahren, und
# welche, lässt sich nachträglich nicht mehr feststellen.
#
# Diese Zeile ist zugleich das SOLL für die Skriptfassung des Wächters. Der
# Wächter schreibt sie beim Update fort und stellt im nächsten Schleifendurchlauf
# darauf um — er holt die neue Fassung aus dem zugehörigen Image, prüft ihre
# Signatur und ersetzt sich per `exec` durch sie (updater/updater.sh:
# merke_wechsel_vor / pruefe_skriptwechsel).
#
# DER CONTAINER WIRD DABEI NICHT AUSGETAUSCHT, und darauf beruht das
# Festschreiben. Zwei Entwürfe haben es anders versucht und sind beide im
# Zerstörungstest durchgefallen (01.08.2026 und 02.08.2026): Docker beendete den
# Wächter mitten im Befehl, der Nachfolger blieb im Zustand „Created" liegen —
# ein Zustand, der gemessen NIE von selbst heilt. Seither ändert sich nur noch
# das Skript, nicht der Container.
#
# BELEGT AM 02.08.2026 auf test.verumind.de, acht Zerstörungstests:
#   • Normalfall — Container-ID, Startzeit und Neustartzahl unverändert, nur die
#     Skriptfassung wechselte (B1); zwei Wechsel unmittelbar nacheinander
#     ebenfalls (B8).
#   • Kaputte Fassung — nach drei Startversuchen gesperrt, Rückfall auf die
#     vorherige, und auch ein Neustart zieht die gesperrte nicht wieder (B2).
#   • Ungültige Signatur und fehlendes Image — abgelehnt, die bisherige Fassung
#     lief unverändert weiter, das Update selbst blieb gültig (B3).
#   • Harter Server-Neustart mitten im Update — der Wächter räumte auf, rollte
#     zurück und holte die Dienste von selbst zurück, ohne einen Befehl (B4).
#   • Backend startet nicht — sauberer Rückfall, Wächter unbeschädigt (B5).
#   • Tausch mitten im Lauf — griff erst nach dessen Ende (B6).
#
# Das Image selbst muss dadurch praktisch nie getauscht werden. Wenn doch
# (Basis-Image, Startlader, Schlüsselwechsel), steht der Weg in der
# Störungstabelle von docs/kunden-installation.md.
VERUMIND_UPDATER_VERSION=${VERUMIND_VERSION}
VERUMIND_REGISTRY=ghcr.io/${REG_ORG}

POSTGRES_DB=verumind_hub
POSTGRES_USER=verumind
POSTGRES_PASSWORD=${POSTGRES_PASSWORD}

JWT_ACCESS_SECRET=${JWT_ACCESS_SECRET}
JWT_REFRESH_SECRET=${JWT_REFRESH_SECRET}
JWT_ACCESS_EXPIRES_IN=15m
JWT_REFRESH_EXPIRES_IN=7d
TWOFA_ENCRYPTION_KEY=${TWOFA_ENCRYPTION_KEY}
CRM_ENCRYPTION_KEY=${CRM_ENCRYPTION_KEY}

SEED_ADMIN_EMAIL=${SEED_ADMIN_EMAIL}
SEED_ADMIN_PASSWORD=${SEED_ADMIN_PASSWORD}

DOMAIN=${DOMAIN}
ACME_EMAIL=${ACME_EMAIL}
ACME_CA=
APP_URL=https://${DOMAIN}

# Versionsquelle für die Update-Prüfung (zentral von verumind gepflegt). Damit meldet
# das Portal automatisch „Update verfügbar", sobald eine neuere Version erscheint.
VERUMIND_UPDATE_MANIFEST_URL=${MANIFEST_URL}

SMTP_HOST=
SMTP_PORT=587
SMTP_USER=
SMTP_PASSWORD=
SMTP_FROM=verumind Hub <noreply@${DOMAIN}>

N8N_LEADGEN_WEBHOOK_URL=
N8N_WEBHOOK_SECRET=${N8N_WEBHOOK_SECRET}

SEED_TEST_LEADS=false
AUDIT_LOG_RETENTION_DAYS=90
LEADGEN_ENRICH_CONCURRENCY=2
LEADGEN_ENRICH_STUCK_MINUTES=20
EOF
ok ".env geschrieben (Rechte 600)"

# Die Kundendatei gehört der Installation: Eine vorhandene bleibt, wie sie ist.
case ":$COMPOSE_WERT:" in
  *":$KUNDENDATEI:"*)
    if [ ! -e "$KUNDENDATEI" ]; then
      ( umask 022 && printf '%s\n' "$KUNDENDATEI_INHALT" > "$KUNDENDATEI" )
      ok "$KUNDENDATEI angelegt (für Anpassungen dieser Installation)"
    fi
    ;;
esac

# ── 6. Images laden + starten ─────────────────────────────────────────────────
if [ -n "$REG_TOKEN" ]; then
  say "Melde an der Registry an…"
  echo "$REG_TOKEN" | docker login ghcr.io -u "$REG_USER" --password-stdin >/dev/null \
    || die "Registry-Login fehlgeschlagen — Token/Benutzer prüfen."
  ok "Registry-Login ok"
else
  # Nur erreichbar, wenn oben eine bestehende Anmeldung erkannt wurde.
  ok "Bestehende Registry-Anmeldung wird verwendet"
fi

say "Lade Images (kann beim ersten Mal dauern)…"
dc pull
say "Starte den Stack…"
dc up -d

# ── 7. Auf Bereitschaft warten ────────────────────────────────────────────────
say "Warte auf Bereitschaft des Backends…"
ready=0
for i in $(seq 1 60); do
  if dc exec -T backend \
       node -e "require('http').get('http://127.0.0.1:3000/health',r=>process.exit(r.statusCode===200?0:1)).on('error',()=>process.exit(1))" >/dev/null 2>&1; then
    ready=1; break
  fi
  sleep 3
done

echo
if [ "$ready" = "1" ]; then
  ok "Installation abgeschlossen."
  say "Portal:  https://${DOMAIN}"
  # Gesamtreview W5: Der Seed legt keinen Admin an, sobald es einen gibt — beim
  # erneuten Durchlauf ist eine neu eingegebene Adresse also KEIN Login.
  say "Login:   ${SEED_ADMIN_EMAIL}  (Passwort wie eingegeben — gilt, wenn es noch keinen Administrator gab)"
  warn "Hinweis: Das HTTPS-Zertifikat kann nach dem ersten Aufruf ein paar Sekunden brauchen."
  warn "Bitte nach dem ersten Login das Admin-Passwort ändern."

  # ── Der nächste Schritt gehört auf DIESEN Bildschirm ────────────────────────
  #
  # Hier stand bisher nichts über die Lizenz — das Wort kam im ganzen Skript
  # nicht vor. Ein Kunde las „Installation abgeschlossen", meldete sich an und
  # fand ein Portal ohne Module, ohne zu wissen warum. Die Erklärung steht in
  # Abschnitt 10 der Anleitung, also in einem Dokument, das er an dieser Stelle
  # gerade zugeklappt hat. Aufgefallen am 03.08.2026 beim ersten vollständigen
  # Installationstest.
  #
  # Die Instanz-Kennung wird für die Anforderung gebraucht und ist hier bereits
  # verfügbar: Die Warteschleife oben endet erst, wenn /health antwortet, und
  # dort steht sie. Ohne diese Zeile müsste der Kunde sie erst im Portal suchen.
  INSTANZ_KENNUNG="$(dc exec -T backend \
    node -e "require('http').get('http://127.0.0.1:3000/health',r=>{let b='';r.on('data',d=>b+=d).on('end',()=>{try{process.stdout.write(JSON.parse(b).instanceId||'')}catch{}})}).on('error',()=>{})" \
    2>/dev/null | tr -d '\r\n')"

  echo
  say "Nächster Schritt: Module freischalten"
  say "  Das Portal zeigt noch keine Module — dafür wird eine Lizenz benötigt."
  if [ -n "$INSTANZ_KENNUNG" ]; then
    say "  Instanz-Kennung:  ${INSTANZ_KENNUNG}"
    say "  Diese Kennung an aktivierung@verumind.de senden (Vorlage: INSTALLATION.md, Abschnitt 10)."
  else
    say "  Instanz-Kennung und Vorlage: INSTALLATION.md, Abschnitt 10."
  fi
else
  warn "Der Stack läuft, aber das Backend meldete sich nicht rechtzeitig als bereit."
  warn "Status prüfen:  ${DC_TEXT} ps"
  warn "Logs ansehen:   ${DC_TEXT} logs backend"
fi
