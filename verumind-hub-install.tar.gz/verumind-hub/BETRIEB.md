# verumind Hub — Betrieb

**Nachschlagewerk für den laufenden Betrieb.** Für die Erstinstallation gibt es ein
eigenes Dokument: **INSTALLATION.md** (liegt daneben).

Alle Befehle werden im Installationsverzeichnis ausgeführt:

```bash
cd /opt/verumind-hub
```

> **Warum überall `-f docker-compose.prod.yml`?** Ohne diese Angabe sucht Docker
> Compose eine Datei namens `docker-compose.yml` — die es hier nicht gibt. Die
> Fehlermeldung (`no configuration file provided`) ist schwer zu deuten. Geben Sie
> die Datei immer mit an.

---

## Inhalt

1. [Zustand prüfen](#1--zustand-prüfen)
2. [Stoppen und Starten](#2--stoppen-und-starten)
3. [Verhalten nach einem Server-Neustart](#3--verhalten-nach-einem-server-neustart)
4. [Updates](#4--updates)
5. [Datensicherung](#5--datensicherung)
6. [Entwicklerzugang für verumind](#6--entwicklerzugang-für-verumind)
7. [Ausgesperrt? Administrator-Konto zurücksetzen](#7--ausgesperrt-administrator-konto-zurücksetzen)
8. [Protokolle und Support](#8--protokolle-und-support)
9. [Sicherheit und Datenschutz](#9--sicherheit-und-datenschutz)
10. [Fehlerbehebung](#10--fehlerbehebung)
11. [Kommando-Spickzettel](#11--kommando-spickzettel)

---

## 1 · Zustand prüfen

**Laufen alle Komponenten?**

```bash
cd /opt/verumind-hub
docker compose -f docker-compose.prod.yml ps
```

Erwartet werden **fünf** Container:

```
NAME                      STATUS
verumind-hub-backend-1    Up 26 minutes (healthy)
verumind-hub-caddy-1      Up 26 minutes
verumind-hub-frontend-1   Up 26 minutes (healthy)
verumind-hub-postgres-1   Up 27 minutes (healthy)
verumind-hub-updater-1    Up 27 minutes
```

`postgres`, `backend` und `frontend` zeigen `(healthy)`. `caddy` und `updater`
haben keine Gesundheitsprüfung — dass sie `Up` sind, genügt.

**Antwortet das Portal?**

```bash
curl -s https://hub.ihre-firma.de/backend/health
```

Erwartet:

```json
{"status":"ok","db":"connected","version":"<version>",
 "instanceId":"296f8d8f-36f8-4da0-907e-5dcf668e92c1",
 "timestamp":"2026-08-03T07:59:29.851Z"}
```

Versionsnummer, Instanz-Kennung und Zeitstempel sind bei Ihnen andere.

| Feld | Bedeutung |
|---|---|
| `status` | `ok` = Backend arbeitet |
| `db` | `connected` = Datenbankverbindung steht |
| `version` | Die laufende Programmversion |
| `instanceId` | Ihre Instanz-Kennung (für Lizenz und Supportanfragen) |

**Ist das HTTPS-Zertifikat gültig?**

```bash
echo | openssl s_client -connect hub.ihre-firma.de:443 \
  -servername hub.ihre-firma.de 2>/dev/null \
  | openssl x509 -noout -issuer -subject -dates
```

Der Reverse-Proxy erneuert das Zertifikat selbstständig. Fällt die Erneuerung aus,
warnt Let's Encrypt per E-Mail an die bei der Installation angegebene Adresse.

---

## 2 · Stoppen und Starten

```bash
cd /opt/verumind-hub

docker compose -f docker-compose.prod.yml stop     # anhalten
docker compose -f docker-compose.prod.yml up -d    # wieder starten
```

> **Niemals** `down -v` oder `rm -v` verwenden. Die Option `-v` löscht die
> Docker-Volumes — **und damit die gesamte Datenbank.** Zum Anhalten genügt `stop`.

---

## 3 · Verhalten nach einem Server-Neustart

Alle Komponenten starten nach einem Neustart des Servers **automatisch** wieder.
Ein manueller Eingriff ist nicht erforderlich.

**Das ist geprüft.** Gemessen am 03.08.2026 auf Ubuntu 26.04 LTS:

| | |
|---|---|
| Alle fünf Dienste zurück | ja |
| Portal wieder erreichbar nach | **36 Sekunden** ab Auslösen des Neustarts |
| HTTPS-Zertifikat | unverändert gültig, keine Neuausstellung nötig |
| Datenbestand | unverändert |
| Instanz-Kennung | unverändert |
| Administrator-Anmeldung | funktioniert |

Rechnen Sie im Regelfall mit **etwa einer Minute** vom Neustart bis zum
erreichbaren Portal.

**Nach einem Neustart prüfen** — die Befehle aus [Abschnitt 1](#1--zustand-prüfen):

```bash
cd /opt/verumind-hub
docker compose -f docker-compose.prod.yml ps
curl -s https://hub.ihre-firma.de/backend/health
```

*(Technischer Hintergrund: Alle Container laufen mit der Neustart-Regel
`unless-stopped`. Container, die Sie zuvor bewusst mit `stop` angehalten haben,
bleiben nach einem Neustart bewusst aus.)*

---

## 4 · Updates

Sobald verumind eine neuere Version veröffentlicht, zeigt das Portal unter
*Einstellungen → Installation → Aktualisierung* den Hinweis **„Update verfügbar"**. Ein
Administrator startet das Update per Knopfdruck.

Der Update-Wächter führt es sicher aus:

```
Datenbank sichern → neue Version laden → tauschen → Gesundheitscheck
                                                          ↓ bei Fehler
                                          automatisch zurück auf die vorige Version
```

Während des Updates ist das Portal **ein bis zwei Minuten** nicht erreichbar.

> Updates werden **nicht** von Hand über die Kommandozeile eingespielt, sondern
> über das Portal. Nur so laufen Sicherung, Gesundheitscheck und Rückrollen mit.

**Voraussetzung:** ein gültiges Registry-Token. Es ist an einen aktiven
Wartungsvertrag gebunden. Ist es abgelaufen, können keine neuen Versionen geladen
werden — bereits laufende Container laufen unverändert weiter.

---

## 5 · Datensicherung

> **Eine Sicherung ist nur vollständig, wenn sie beides enthält: die Datenbank
> UND die Datei `.env`.**

Die `.env` enthält die Verschlüsselungsschlüssel der Installation. Geht sie
verloren, lassen sich gespeicherte CRM-Zugangsdaten und die
Zwei-Faktor-Geheimnisse der Benutzer **nicht mehr entschlüsseln** — selbst dann
nicht, wenn die Datenbanksicherung vollständig ist.

Vor jedem Update wird automatisch eine Datenbank-Sicherung erstellt. **Das ersetzt
keine regelmäßige eigene Sicherung.**

### Sicherung erstellen

```bash
cd /opt/verumind-hub

# Datenbank sichern
docker compose -f docker-compose.prod.yml exec -T postgres \
  pg_dump -U verumind verumind_hub | gzip > sicherung-$(date +%F).sql.gz

# Konfiguration sichern (enthält Geheimnisse — geschützt aufbewahren!)
cp .env sicherung-env-$(date +%F)
```

Bewahren Sie **beide Dateien am selben Ort und gleich lange** auf. Die
`sicherung-env-*` enthält Zugangsgeheimnisse im Klartext — behandeln Sie sie
entsprechend.

Binden Sie beides in Ihr vorhandenes Backup-Verfahren ein. Alternativ zur
Datenbank-Sicherung können Sie die Docker-Volumes sichern; die Anwendungsdaten
liegen im Volume `verumind_hub_postgres`.

### Woran Sie erkennen, dass die Sicherung brauchbar ist

```bash
gzip -t sicherung-$(date +%F).sql.gz && echo "Archiv unversehrt"
zcat sicherung-$(date +%F).sql.gz | head -5
```

Die ersten Zeilen müssen wie ein PostgreSQL-Dump aussehen (`-- PostgreSQL database
dump`). Eine Datei von wenigen hundert Byte deutet auf einen Fehlschlag hin.

---

## 6 · Entwicklerzugang für verumind

Über den Entwicklerzugang kann verumind bei Bedarf als Administrator auf Ihre
Installation zugreifen — etwa zur Fehlersuche im Störungsfall.

**Empfehlung:** direkt nach der Installation einrichten. Tritt später ein Problem
auf, kann verumind sofort helfen, statt erst auf die Freischaltung zu warten.

### Einrichten

1. *Einstellungen → Lizenz & Support → Entwicklerzugang → „Entwicklerzugang aktivieren"*
2. Der Hub erzeugt einen **Einladungslink** — 24 Stunden gültig, nur einmal
   einlösbar. Ein fertiger Mailtext steht zum Kopieren bereit.
3. **Sie senden den Link selbst** an **support@verumind.de**. Der Hub verschickt
   bewusst keine E-Mail.
4. verumind löst den Link ein und richtet dabei eigenes Passwort und
   Zwei-Faktor-Authentifizierung ein.
5. Das Konto erscheint in der Benutzerverwaltung gekennzeichnet als
   **„verumind Support"**.

### Sie behalten die Kontrolle

- Sie entscheiden, ob ein Zugang besteht.
- Sie sehen den Zustand jederzeit: *offen · aktiv · abgelaufen · widerrufen*.
- Sie können den Zugang jederzeit **widerrufen** — das Konto wird entfernt,
  laufende Sitzungen enden sofort.
- Jeder Schritt wird im Protokoll festgehalten.

**Sicherheit:** Der Einladungslink allein genügt nicht. Zum Einlösen ist zusätzlich
ein kryptografischer Nachweis erforderlich, den nur verumind erzeugen kann. Ein
abgefangener Link verschafft daher keinen Zugang. Der Nachweis ist an genau diese
Installation und genau diese Einladung gebunden.

---

## 7 · Ausgesperrt? Administrator-Konto zurücksetzen

Wenn niemand mehr ins Portal kommt — Passwort vergessen, Zweitgerät für die
Zwei-Faktor-Anmeldung verloren — hilft `admin-reset.sh`. Es liegt im
Installationsverzeichnis und wird direkt auf dem Server ausgeführt.

```bash
cd /opt/verumind-hub

./admin-reset.sh list                                  # alle Konten anzeigen
./admin-reset.sh password <email> [neues-passwort]     # Passwort neu setzen
./admin-reset.sh 2fa-off  <email>                      # 2FA zurücksetzen
./admin-reset.sh promote  <email>                      # zum Administrator machen
```

Beispiel:

```bash
./admin-reset.sh password admin@ihre-firma.de
```

**Jeder Eingriff wird im Audit-Log der Instanz protokolliert.** Voraussetzung ist,
dass die Container laufen — das Skript arbeitet über den Backend-Container.

---

## 8 · Protokolle und Support

### Diagnose aus dem Portal

*Einstellungen → Lizenz & Support → Support & Diagnose → „Diagnose herunterladen"* exportiert die letzten
Protokolle **ohne Geheimnisse** als Datei. Senden Sie diese an **support@verumind.de**.

### Protokolle auf dem Server

```bash
cd /opt/verumind-hub

docker compose -f docker-compose.prod.yml logs backend        # Backend
docker compose -f docker-compose.prod.yml logs -f backend     # laufend mitlesen
docker compose -f docker-compose.prod.yml logs caddy          # HTTPS / Zertifikate
docker compose -f docker-compose.prod.yml logs --tail=100     # alle, letzte 100 Zeilen
```

### Was Sie einer Supportanfrage beilegen sollten

- Die **Instanz-Kennung** (`curl -s https://hub.ihre-firma.de/backend/health`)
- Den Inhalt von `PAKET-VERSION`
- Die Ausgabe von `docker compose -f docker-compose.prod.yml ps`
- Die Diagnose-Datei aus dem Portal, falls erreichbar

### Kontakt

| Adresse | Wofür |
|---|---|
| **aktivierung@verumind.de** | Lizenz und Freischaltung |
| **support@verumind.de** | Support, Störungen, Registry-Token |

---

## 9 · Sicherheit und Datenschutz

- Die Datei **`.env`** enthält alle Zugangsgeheimnisse. Sie ist nur für den
  Eigentümer lesbar, darf nicht weitergegeben und nicht in eine Versionsverwaltung
  eingecheckt werden. Sie ist — neben den Volumes — der **komplette Zustand** der
  Installation.
- Der Datenverkehr ist durchgehend per **HTTPS** verschlüsselt.
- **Datenhoheit:** Alle Daten verbleiben auf Ihrem Server bzw. in Ihrem
  Rechenzentrum.
- Der **Registry-Zugang** ist an einen aktiven Wartungsvertrag gebunden.
- Der **Entwicklerzugang** besteht nur, wenn Sie ihn aktivieren. Jederzeit
  widerrufbar, in der Benutzerverwaltung gekennzeichnet, erfordert
  Zwei-Faktor-Authentifizierung (Abschnitt 6).
- Der **Update-Wächter** ist die einzige Komponente mit erweitertem Zugriff auf die
  Container-Steuerung. Er wird ausschließlich durch eine Administrator-Aktion im
  Portal ausgelöst.

**Empfehlung zum Registry-Token:** Es liegt nach der Installation in `.env` und in
`/root/.docker/config.json`. Wird der Server weitergegeben oder außer Betrieb
genommen, lassen Sie das Token bei verumind zurückziehen.

---

## 10 · Fehlerbehebung

| Symptom | Ursache / Lösung |
|---|---|
| **Kein HTTPS / Zertifikatsfehler** | DNS-A-Record zeigt (noch) nicht auf den Server, oder Port 80/443 ist nicht erreichbar. Prüfen: `sh pruefe-server.sh hub.ihre-firma.de --ohne-token`. Danach `docker compose -f docker-compose.prod.yml logs caddy`. |
| **Portal nicht erreichbar** | `docker compose -f docker-compose.prod.yml ps` — laufen alle fünf Container? |
| **Backend meldet sich nicht bereit** | `docker compose -f docker-compose.prod.yml logs backend` |
| **Keine Module sichtbar** | Normal, solange keine Lizenz hinterlegt ist. Siehe INSTALLATION.md, Abschnitt 10. |
| **Registry-Login fehlgeschlagen** | Token prüfen. Test: `docker login ghcr.io -u verumind-deploy`. Token evtl. abgelaufen — neues bei **support@verumind.de** anfordern. |
| **Images laden nicht, Login ging aber** | Fast immer eine Firewall, die `ghcr.io` freigibt, aber **`pkg-containers.githubusercontent.com`** nicht. Siehe `firewall-ziele.txt`. |
| **`… not found` beim Laden der Images** | Es wurde eine Version angegeben, die es nicht gibt. Installation erneut starten und bei der Versionsabfrage **Enter** drücken. |
| **`no configuration file provided`** | `-f docker-compose.prod.yml` vergessen. |
| **Installation abgebrochen — erneut starten** | `sudo ./install.sh` nochmals ausführen. Das Skript erkennt die bestehende Konfiguration und fragt nach, bevor es sie überschreibt. **Achtung:** Beim Überschreiben werden Admin-Passwort und alle Zugangsgeheimnisse **neu vergeben**. |
| **Niemand kommt mehr ins Portal** | `./admin-reset.sh` — siehe [Abschnitt 7](#7--ausgesperrt-administrator-konto-zurücksetzen). |
| **Update schlägt fehl** | Der Wächter rollt automatisch auf die vorige Version zurück; eine Sicherung liegt bereit. Diagnose herunterladen und an **support@verumind.de** senden. |
| **Nach Server-Neustart läuft nichts** | Erwartet wird: alles kommt binnen ~1 Minute von selbst zurück ([Abschnitt 3](#3--verhalten-nach-einem-server-neustart)). Falls nicht: `docker compose -f docker-compose.prod.yml up -d`, dann Protokolle prüfen und verumind informieren. |

---

## 11 · Kommando-Spickzettel

```bash
# Verzeichnis der Installation
cd /opt/verumind-hub

# Status
docker compose -f docker-compose.prod.yml ps
curl -s https://hub.ihre-firma.de/backend/health

# Protokolle
docker compose -f docker-compose.prod.yml logs backend
docker compose -f docker-compose.prod.yml logs -f backend

# Anhalten / Starten   (NIEMALS mit -v — das löscht die Datenbank)
docker compose -f docker-compose.prod.yml stop
docker compose -f docker-compose.prod.yml up -d

# Sicherung (Datenbank UND .env — beides zusammen)
docker compose -f docker-compose.prod.yml exec -T postgres \
  pg_dump -U verumind verumind_hub | gzip > sicherung-$(date +%F).sql.gz
cp .env sicherung-env-$(date +%F)

# Server erneut prüfen (ändert nichts)
sh pruefe-server.sh hub.ihre-firma.de --ohne-token

# Ausgesperrt
./admin-reset.sh list
./admin-reset.sh password <email>

# Zertifikat ansehen
echo | openssl s_client -connect hub.ihre-firma.de:443 \
  -servername hub.ihre-firma.de 2>/dev/null | openssl x509 -noout -issuer -dates
```

---

*verumind GmbH*
